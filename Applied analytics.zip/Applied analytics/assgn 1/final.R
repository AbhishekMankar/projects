rm(list=ls())
library(readr)
library(magrittr)

# Load required libraries
library(ggplot2)
library(dplyr)
library(stats)
library(readr)  # Make sure you have this library loaded for reading CSV files

# Set working directory
setwd("F:/Applied Analytics/assgn 1")

# Load Melbourne and Sydney datasets
melbourneData <- read_csv("Climate Data Melbourne-2.csv")
sydneyData <- read_csv("Climate Data Sydney-2.csv")







par(mfrow = c(2, 4))  # Arrange plots in a 2x3 grid

hist(melbourneData$`Solar exposure`, main = "Solar Exposure")
qqnorm(melbourneData$`Solar exposure`, main = "Q-Q Plot")

hist(melbourneData$`Maximum temperature`, main = "Melbourne Max Temperature")
qqnorm(melbourneData$`Maximum temperature`, main = "Q-Q Plot")

hist(sydneyData$`Solar exposure`, main = "Sydney Solar Exposure")
qqnorm(sydneyData$`Solar exposure`, main = "Q-Q Plot")

hist(sydneyData$`Maximum temperature`, main = "Sydney Max Temperature")
qqnorm(sydneyData$`Maximum temperature`, main = "Q-Q Plot")


#melbourne_hist_maxtemp <- ggplot(melbourneData, aes(x = `Maximum temperature`)) +   
#  stat_function(fun = dnorm,                 
#  args=list(mean = mean(melbourneData$`Maximum temperature`),                             
#       sd = sd(melbourneData$`Maximum temperature`)),                 
#       col = "red",                 
#       size = 1)





# For Melbourne - Maximum temperature
melbourne_max_temp_stats <- summary(melbourneData$`Maximum temperature`)
melbourne_max_temp_stats
melbourneData$`Maximum temperature` %>% hist()

# For Melbourne - Solar exposure
melbourne_solar_stats <- summary(melbourneData$Solar.exposure)
melbourne_solar_stats
melbourne_data$Solar.exposure %>% hist()

# For Sydney - Maximum temperature
sydney_max_temp_stats <- summary(sydneyData$Maximum.temperature)
sydney_max_temp_stats
sydney_data$Maximum.temperature %>% hist()

# For Sydney - Solar exposure
sydney_solar_stats <- summary(sydneyData$Solar.exposure)
sydney_solar_stats
sydney_data$Solar.exposure %>% hist()










MelSolarExposureHistogram <- melbourneData %>%
  ggplot() +
  geom_histogram(
    aes(x = `Solar exposure`, y = (..count..)/sum(..count..)),
    position = "identity", binwidth = 0.8, 
    fill = "#ffdfba", color = "white"
  ) +
  labs(x = "Solar exposure", y = "Proportion", title = NULL) +
  theme_classic() +
  geom_vline(
    aes(xintercept = mean(`Solar exposure`)),
    color = "black", 
    linetype = "dashed", size = 0.6
  ) +
  annotate(
    "text", x = 25, y = 0.20, 
    label = paste("Mean:", round(mean(melbourneData$`Solar exposure`), 2)),
    color = "black",
    size = 4
  ) +
  geom_vline(
    aes(xintercept = median(`Solar exposure`)),
    color = "grey", 
    linetype = "dashed", size = 0.6
  ) +
  annotate(
    "text", x = 25, y = 0.18, 
    label = paste("Median:", round(median(melbourneData$`Solar exposure`), 5)),
    color = "grey",
    size = 4
  ) +
  stat_function(
    fun = dnorm,
    args = list(mean = mean(melbourneData$`Solar exposure`),
                sd = sd(melbourneData$`Solar exposure`)),
    color = "red", 
    size = 0.8
  ) +
  annotate(
    "text", x = 25, y = 0.16, 
    label = paste("Standard Deviation:", round(sd(melbourneData$`Solar exposure`), 2)),
    color = "red",
    size = 4
  ) +
  theme(
    plot.title = element_text(hjust = 0.5),
    axis.text.y = element_text(size = 10)  
  ) +
  labs(title = "Melbourne Solar Exposure Distribution") +
  coord_cartesian(ylim = c(0, 0.20)) 


MelSolarExposureHistogram


MelTemperatureHistogram <- melbourneData %>%
  ggplot() +
  geom_histogram(
    aes(x = `Solar exposure`, y = (..count..)/sum(..count..)),
    position = "identity", binwidth = 0.8, 
    fill = "#ffffba", color = "white"
  ) +
  labs(x = "Solar exposure", y = "Proportion", title = NULL) +
  theme_classic() +
  geom_vline(
    aes(xintercept = mean(`Maximum temperature`)),
    color = "black", 
    linetype = "dashed", size = 0.6
  ) +
  annotate(
    "text", x = 30, y = 0.20, 
    label = paste("Mean:", round(mean(melbourneData$`Maximum temperature`), 2)),
    color = "black",
    size = 4
  ) +
  geom_vline(
    aes(xintercept = median(`Maximum temperature`)),
    color = "grey", 
    linetype = "dashed", size = 0.6
  ) +
  annotate(
    "text", x = 30, y = 0.18, 
    label = paste("Median:", round(median(melbourneData$`Maximum temperature`), 5)),
    color = "grey",
    size = 4
  ) +
  stat_function(
    fun = dnorm,
    args = list(mean = mean(melbourneData$`Maximum temperature`),
                sd = sd(melbourneData$`Maximum temperature`)),
    color = "red", 
    size = 0.8
  ) +
  annotate(
    "text", x = 30, y = 0.16, 
    label = paste("Standard Deviation:", round(sd(melbourneData$`Maximum temperature`), 2)),
    color = "red",
    size = 4
  ) +
  theme(
    plot.title = element_text(hjust = 0.5),
    axis.text.y = element_text(size = 10)  
  ) +
  labs(title = "Melbourne Maximum Temperature Distribution") +
  coord_cartesian(ylim = c(0, 0.20))  


MelTemperatureHistogram




SydSolarExposureHistogram <- sydneyData %>%
  ggplot() +
  geom_histogram(
    aes(x = `Solar exposure`, y = (..count..)/sum(..count..)),
    position = "identity", binwidth = 0.8, 
    fill = "#baffc9", color = "white"
  ) +
  labs(x = "Solar exposure", y = "Proportion", title = NULL) +
  theme_classic() +
  geom_vline(
    aes(xintercept = mean(`Solar exposure`)),
    color = "black", 
    linetype = "dashed", size = 0.6
  ) +
  annotate(
    "text", x = 25, y = 0.20, 
    label = paste("Mean:", round(mean(sydneyData$`Solar exposure`), 2)),
    color = "black",
    size = 4
  ) +
  geom_vline(
    aes(xintercept = median(`Solar exposure`)),
    color = "grey", 
    linetype = "dashed", size = 0.6
  ) +
  annotate(
    "text", x = 25, y = 0.18, 
    label = paste("Median:", round(median(sydneyData$`Solar exposure`), 5)),
    color = "grey",
    size = 4
  ) +
  stat_function(
    fun = dnorm,
    args = list(mean = mean(sydneyData$`Solar exposure`),
                sd = sd(sydneyData$`Solar exposure`)),
    color = "red", 
    size = 0.8
  ) +
  annotate(
    "text", x = 25, y = 0.16, 
    label = paste("Standard Deviation:", round(sd(sydneyData$`Solar exposure`), 2)),
    color = "red",
    size = 4
  ) +
  theme(
    plot.title = element_text(hjust = 0.5),
    axis.text.y = element_text(size = 10)  
  ) +
  labs(title = "Sydney Solar Exposure Distribution") +
  coord_cartesian(ylim = c(0, 0.20))  


SydSolarExposureHistogram




MelTemperatureHistogram <- melbourneData %>%
  ggplot() +
  geom_histogram(
    aes(x = `Solar exposure`, y = (..count..)/sum(..count..)),
    position = "identity", binwidth = 0.8, 
    fill = "#bae1ff", color = "white"
  ) +
  labs(x = "Solar exposure", y = "Proportion", title = NULL) +
  theme_classic() +
  geom_vline(
    aes(xintercept = mean(`Maximum temperature`)),
    color = "black", 
    linetype = "dashed", size = 0.6
  ) +
  annotate(
    "text", x = 30, y = 0.20, 
    label = paste("Mean:", round(mean(melbourneData$`Maximum temperature`), 2)),
    color = "black",
    size = 4
  ) +
  geom_vline(
    aes(xintercept = median(`Maximum temperature`)),
    color = "grey", 
    linetype = "dashed", size = 0.6
  ) +
  annotate(
    "text", x = 30, y = 0.18, 
    label = paste("Median:", round(median(melbourneData$`Maximum temperature`), 5)),
    color = "grey",
    size = 4
  ) +
  stat_function(
    fun = dnorm,
    args = list(mean = mean(melbourneData$`Maximum temperature`),
                sd = sd(melbourneData$`Maximum temperature`)),
    color = "red", 
    size = 0.8
  ) +
  annotate(
    "text", x = 30, y = 0.16, 
    label = paste("Standard Deviation:", round(sd(melbourneData$`Maximum temperature`), 2)),
    color = "red",
    size = 4
  ) +
  theme(
    plot.title = element_text(hjust = 0.5),
    axis.text.y = element_text(size = 10) 
  ) +
  labs(title = "Melbourne Maximum Temperature Distribution") +
  coord_cartesian(ylim = c(0, 0.20))  


MelTemperatureHistogram