# Run Job 2 to calculate standard deviation using mean from Job 1
hadoop jar /path/to/hadoop-streaming.jar \
  -D mapred.reduce.tasks=3 \               # Specifying the number of reducers
  -file mapper2.py -mapper mapper2.py \
  -file reducer2.py -reducer reducer2.py \
  -file mean_file.txt -input /input/data.txt \  # Input data for Job 2 along with mean file
  -output /output/job2                       # Specifying the output path for Job 2