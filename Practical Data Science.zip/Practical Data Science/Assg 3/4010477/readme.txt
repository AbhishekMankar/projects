Name: Abhishek Dnyandeo Mankar
Student ID: s4010477

Contents:
1. Assignment3_framework.ipynb
2. Slides.mp4

1. Assignment3 framework.ipynb:
   - Description:
     This Jupyter Notebook contains the implementation of a collaborative filtering algorithm using Adjusted Euclidean Distance (AED) for user similarity measurement.
   
   - How to Run:
     1. Ensure you have Jupyter Notebook or JupyterLab installed on your system. If not, you can install it using Anaconda or pip:
        - Using Anaconda: `conda install -c conda-forge notebook`
        - Using pip: `pip install notebook`
     
     2. Place the `Assignment3_framework.ipynb` file in your working directory.

     3. Launch Jupyter Notebook or JupyterLab:
        - Open a terminal or command prompt.
        - Navigate to the directory containing `Assignment3_framework.ipynb`.
        - Run the command: `jupyter notebook` or `jupyter lab`.

     4. In the Jupyter interface, open the `Assignment3_framework.ipynb` file.

     5. Execute the cells in the notebook sequentially:
        - Click on the first cell and press `Shift + Enter` to execute it.
        - Continue executing each cell in order to perform data normalization, similarity calculation, rating prediction, and evaluation.


2. Slides.mp4:
   - Description:
     This video contains a presentation recording that explains why the Adjusted Euclidean Distance works,how the Adjusted Euclidean Distance works and comparison of results between PCC and AED
   - How to View:
     1. Open the `Slides.mp4` file using any media player that supports MP4 format.
