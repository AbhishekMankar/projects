Name: Abhishek Dnyandeo Mankar
Student ID: s4010477

Instructions for Executing Submitted Script Files:

1. Dataset File:
   - File Name: glass.csv
   - Description: This file contains the dataset used.
   - Usage: Ensure that the glass.csv file is placed in the same directory as the script files before executing the scripts.

2. Script File:
   - File Name: Assignment2.ipynb
   - Description: This file contains the Python code implemented using Jupyter Notebook.
   - Usage:
     - Ensure that Jupyter Notebook is installed on your system.
     - Open the Assignment2.ipynb file using Jupyter Notebook.
     - Load the dataset correctly.
     - Execute the code cells in the notebook sequentially by pressing Shift + Enter.
     
 
