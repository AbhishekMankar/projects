Name : Abhishek Dnyandeo Mankar
student ID : s4010477


Overview :
--------
This is a Flask-based web application for posting and searching job ads. The application allows users to search for job postings, view job details, and allows admins to post new jobs with an automated category classification feature.


Models :
------
The models (`desc_FT.model` and `descFT_LR.pkl`) are already provided by the university.



files :
-----
- `app.py`: The main Flask application file.
- `preprocessed_job_ads.txt`: The file containing job advertisement data.
- `desc_FT.model`: The trained FastText model.
- `descFT_LR.pkl`: The trained Logistic Regression model.
- `home.html`: Homepage template.
- `search.html`: Search results page template.
- `job_details.html`: Job details page template.
- `admin.html`: Admin page template for posting jobs.
- `home.css`: CSS file for the homepage.
- `search.css`: CSS file for the search results page.
- `job_details.css`: CSS file for the job details page.
- `admin.css`: CSS file for the admin page.


HTML and CSS Files
------------------
- The `.html` files are in the `templates` folder.
- The `.css` files are in the `static` folder.


Usage :
-----
1. Start the Flask application by running `app.py`:
2. Open your web browser and navigate to `http://127.0.0.1:5000/`.
	
