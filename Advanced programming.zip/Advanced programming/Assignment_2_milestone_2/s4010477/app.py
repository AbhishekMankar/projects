#loading the necessary libraries
from flask import Flask, render_template, request, redirect, url_for
from gensim.models.fasttext import FastText
import pickle
import numpy as np
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize

app = Flask(__name__)

# Initializing stemmer
stemmer = PorterStemmer()

# Function to load job data from file
def load_job_data(file_path):
    job_data = {}
    with open(file_path, 'r') as file:
        lines = file.readlines()
        job_id = 1
        job = {}
        for line in lines:
            if line.startswith("Category:"):
                if job:
                    job_data[f"job{job_id}"] = job
                    job_id += 1
                    job = {}
                job["category"] = line.split(":", 1)[1].strip()
            elif line.startswith("Title:"):
                job["title"] = line.split(":", 1)[1].strip()
            elif line.startswith("Description:"):
                job["description"] = line.split(":", 1)[1].strip()
        if job:
            job_data[f"job{job_id}"] = job
    return job_data

# Function to generate document vectors from embeddings
def docvecs(embeddings, docs):
    vecs = np.zeros((len(docs), embeddings.vector_size))
    for i, doc in enumerate(docs):
        valid_keys = [term for term in doc if term in embeddings.key_to_index]
        docvec = np.vstack([embeddings[term] for term in valid_keys])
        docvec = np.sum(docvec, axis=0)
        vecs[i, :] = docvec
    return vecs

# Loading job data from the file
job_data = load_job_data('preprocessed_job_ads.txt')

# Loading the FastText model
descFT = FastText.load("desc_FT.model")
descFT_wv = descFT.wv

# Loading the Logistic Regression model
with open("descFT_LR.pkl", 'rb') as file:
    lr_model = pickle.load(file)

# Homepage
@app.route('/')
def index():
    return render_template('home.html')

# search page
@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        # Get the search string from the form
        search_string = request.form.get("searchword", "")
        return redirect(url_for('search_results', searchword=search_string))
    else:
        return redirect('/')

# search result page
@app.route('/search_results')
def search_results():
    search_string = request.args.get("searchword", "")
    stemmed_search_string = ' '.join([stemmer.stem(word) for word in word_tokenize(search_string.lower())])

    # Searching for the string in job data
    job_search_results = []
    for job_id, job in job_data.items():
        title = job["title"]
        description = job["description"]
        stemmed_title = ' '.join([stemmer.stem(word) for word in word_tokenize(title.lower())])
        stemmed_description = ' '.join([stemmer.stem(word) for word in word_tokenize(description.lower())])

        # Checking if the stemmed search string is in the stemmed title or description
        if stemmed_search_string in stemmed_title or stemmed_search_string in stemmed_description:
            job_search_results.append({
                "job_id": job_id,
                "title": title,
                "description": description[:100] + "...",  # Preview of the description
                "category": job.get("category", "")
            })

    # finding Number of search results
    num_results = len(job_search_results)

    return render_template('search.html', num_results=num_results, search_string=search_string,
                           job_search_results=job_search_results)

# job page
@app.route('/jobs/<job_id>')
def job_details(job_id):
    job = job_data.get(job_id)
    if job:
        search_string = request.args.get('search_string', '')
        return render_template('job_details.html', job=job, search_string=search_string)
    else:
        return "Job not found", 404

# admin page
@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        # Reading the form content
        f_title = request.form['title']
        f_content = request.form['description']

        if request.form['button'] == 'Classify':
            # Tokenizing the content to input to the saved model
            tokenized_data = f_content.split(' ')

            # Generating vector representation of the tokenized data
            descFT_dvs = docvecs(descFT_wv, [tokenized_data])

            # Predicting the label of tokenized_data
            y_pred = lr_model.predict(descFT_dvs)
            y_pred = y_pred[0]

            return render_template('admin.html', prediction=y_pred, title=f_title, description=f_content)

        elif request.form['button'] == 'Save':
            # Getting the recommended category
            cat_recommend = request.form['category']

            # Creating a new job entry
            new_job_id = f"job{len(job_data) + 1}"
            job_data[new_job_id] = {
                "title": f_title,
                "description": f_content,
                "category": cat_recommend
            }

            return redirect('/')

    else:
        return render_template('admin.html')

if __name__ == "__main__":   # starting point for the file
    app.run(debug=True)

#References :
# (2024). Instructure.com. https://rmit.instructure.com/courses/134429/pages/week-10-lab?module_item_id=5855668
# (2024). Instructure.com. https://rmit.instructure.com/courses/134429/pages/week-11-lab?module_item_id=5855684
