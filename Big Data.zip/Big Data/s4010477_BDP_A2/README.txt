STEPS TO RUN THE TASKS ON AWS EMR:

Ensure all necessary files are uploaded to the Hadoop cluster node which includes :
noc_region.csv
person_region.csv
person.csv
competitor_event.csv 
medal.csv 
task1.pig
task2-1.pig
task2-2.pig
task2udf.py

Create Input directory on Hadoop Cluster node , using : hadoop fs -mkdir -p /input

Copy the input files to the input directory using the following commands :
hadoop fs -put competitor_event.csv /input/
hadoop fs -put medal.csv /input/
hadoop fs -put noc_region.csv /input/
hadoop fs -put person.csv /input/
hadoop fs -put person_region.csv /input/

Ensure the following CSV files are uploaded to the HDFS /input/ directory:
/input/noc_region.csv
/input/person_region.csv
/input/person.csv
/input/competitor_event.csv
/input/medal.csv


Instructions to run task 1:
To run the script in MapReduce mode : pig -x mapreduce task1.pig
To see the output for task1 : hadoop fs -cat /output/task1/part-*


Instructions to run task 2-1:
To run the script in MapReduce mode : pig -x mapreduce task2-1.pig
To see the output for task2-1 : hadoop fs -cat /output/task2-1/part-*


Instructions to run task 2-1:
Make sure task2udf.py and task2-2.pig are in same place.
To run the script in MapReduce mode : pig -x mapreduce task2-2.pig
To see the output for task2-2 : hadoop fs -cat /output/task2-2/part-*









