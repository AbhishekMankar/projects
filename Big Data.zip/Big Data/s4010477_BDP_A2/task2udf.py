import sys

# Function to replace Null or empty values with 0
def replace_null_with_zero(value):
    # Checking if the value is None or empty (string)
    if value is None or (isinstance(value, str) and (value == '' or value.lower() == 'null')):
        return '0'
    return str(value)

def main():
    for line in sys.stdin:
        line = line.strip()
        fields = line.split('\t')  
        updated_fields = [replace_null_with_zero(field) for field in fields]
        print('\t'.join(updated_fields))

if __name__ == "__main__":
    main()
