Assignment 3: Steps to Run

Prerequisites
1 Download and Install IntelliJ IDEA
  -Use the Community version of IntelliJ IDEA.
2 Install Required Plugins
  -In IntelliJ, install the Scala plugin for this assignment.



Project Setup
1 Create a Scala Maven Project
 -In the New Project window, select Maven Archetype.
 -Name the project (e.g., count).
 -Ensure the JDK version is JDK 1.8.
 -Select org.scala-tools.archetypes:scala-archetype-simple as the archetype.
 -Enter version 1.2.
 -Enter the GroupId in the advanced settings (e.g., streaming).
 -Click Create.

2 Delete the following files:
 -main/scala/streaming/App.scala
 -test/scala/streaming/AppTest.scala
 -test/scala/streaming/MySpec.scala

3 Create a New Scala Class
 -Under the main/scala/streaming package, create a new Scala class.
 -Name the new Scala object (e.g., NetworkWordCount).


4 Add Code
 -Copy and paste the code into NetworkWordCount.scala from the file given

5 Add Dependencies
 -Include the required dependencies in the pom.xml file.

6 Create the .jar File
 -Build the project to generate the .jar file.




Deployment
1 Upload the .jar File
 -Upload the count.jar file to the cluster master node.

2 Monitor a Folder on HDFS
 -Create a folder in HDFS for monitoring:
 -Open a terminal and run: hadoop fs -mkdir /input

3 Run the Spark Job
 -Open a second terminal and execute the following command to run the below :
  spark-submit --class streaming.NetworkWordCount --master yarn --deploy-mode client count.jar hdfs:///input hdfs:///output

4 Store a Text File
 -Use the first terminal to upload a sample text file to the /input directory.
 -Run below command : hadoop fs -put sample.txt /input
 -You can add more files as needed.





Output
After processing, a folder named output will be created on HDFS.