package streaming

import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.rdd.RDD

object NetworkWordCount {
  def main(args: Array[String]): Unit = {
    if (args.length < 2) {
      System.err.println("Usage: NetworkWordCount <inputDirectory> <outputDirectory>")
      System.exit(1)
    }

    // Setting up the Spark configuration and Streaming context for a 3-second batch interval
    val configuration = new SparkConf().setAppName("NetworkWordCount").setMaster("local[*]")
    val streamingContext = new StreamingContext(configuration, Seconds(3))
    streamingContext.checkpoint("/tmp/checkpoint") // Setting checkpoint directory

    val textStream = streamingContext.textFileStream(args(0)) // Monitoring input folder on HDFS

    def extractWords(textLine: String): Array[String] = {
      textLine.split(" ")
        .filter(word => word.forall(_.isLetter))
        .filter(word => word.length >= 3)
    }

    // Task A: Basic Word Count Logic

    val individualWords = textStream.flatMap(extractWords)
    val wordOccurrences = individualWords.map(word => (word, 1)).reduceByKey(_ + _)

    // Counter for Task A output files
    var taskAFileIndex = 1
    wordOccurrences.foreachRDD { (rdd, time) =>
      if (!rdd.isEmpty()) {
        val outputLocation = args(1) + f"/taskA-$taskAFileIndex%03d"
        taskAFileIndex += 1
        rdd.saveAsTextFile(outputLocation)
      }
    }


    // Task B: Word Co-occurrence Calculation

    def formWordPairs(wordArray: Array[String]): Seq[((String, String), Int)] = {
      for {
        i <- wordArray.indices
        j <- wordArray.indices if i != j
      } yield ((wordArray(i), wordArray(j)), 1)
    }

    val pairedWords = textStream.flatMap(extractWords).mapPartitions(wordSet => Iterator(formWordPairs(wordSet.toArray)).flatten)
    val coOccurrenceCounts = pairedWords.reduceByKey(_ + _)

    // Counter for Task B output files
    var taskBFileIndex = 1
    coOccurrenceCounts.foreachRDD { (rdd, time) =>
      if (!rdd.isEmpty()) {
        val outputLocation = args(1) + f"/taskB-$taskBFileIndex%03d"
        taskBFileIndex += 1
        rdd.saveAsTextFile(outputLocation)
      }
    }


    // Task C: Stateful Co-occurrence Tracking with Conditional Saving


    // Update function for tracking cumulative co-occurrences
    val cumulativeUpdateFunc = (newValues: Seq[Int], runningTotal: Option[Int]) => {
      Some(runningTotal.getOrElse(0) + newValues.sum)
    }

    // Stateful DStream to maintain cumulative counts
    val persistentCoOccurrenceCounts = coOccurrenceCounts.updateStateByKey(cumulativeUpdateFunc)

    // Counter for Task C output files
    var taskCFileIndex = 1
    var previousSnapshot: Option[RDD[((String, String), Int)]] = None // Track last RDD snapshot for comparison

    persistentCoOccurrenceCounts.foreachRDD { (rdd, time) =>
      if (!rdd.isEmpty()) {
        // Checking if current RDD has changes compared to the previous
        val isNewData = previousSnapshot match {
          case Some(prevRdd) => !rdd.subtract(prevRdd).isEmpty() // Comparing current with previous RDD
          case None => true // If no previous RDD, it's the first
        }

        // Saving output if there are updates
        if (isNewData) {
          val outputLocation = args(1) + f"/taskC-$taskCFileIndex%03d"
          rdd.coalesce(1).map { case (pair, count) => s"($pair,$count)" }
            .saveAsTextFile(outputLocation)

          taskCFileIndex += 1
          previousSnapshot = Some(rdd) // Updating previous
        }
      }
    }

    streamingContext.start()
    streamingContext.awaitTermination()
  }
}
