#!/usr/bin/env python3
import sys

for input_line in sys.stdin:
    input_line = input_line.strip()

    if not input_line:
        continue

    try:
        taxi_company, trip_count = input_line.split(',')
        
        print(f"{trip_count}\t{taxi_company}")
    
    except ValueError:
        # If line does not have the expected format then print error
        print(f"Error processing line: {input_line}", file=sys.stderr)
        continue
