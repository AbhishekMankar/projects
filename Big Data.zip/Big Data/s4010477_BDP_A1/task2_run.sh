#!/bin/bash

# Reading the number of iterations and initial medoids from initialization.txt
iterations=$(head -n 1 /home/hadoop/initialization.txt)  # First line contains the iteration count
initial_medoids_file="initialization.txt"

# files for storing medoid updates
new_medoids_file="updated_medoids.txt"  # For medoids after each iteration
previous_medoids_file="last_medoids.txt"  # For tracking previous medoids
log_output="/home/hadoop/medoids_log.txt"  # Log file for iterations
final_medoids_output="final_medoids.txt"  # File to save final medoids


> $log_output  # Clearing any existing log entries
> $final_medoids_output

# Extracting initial medoids, excluding the first line, and save to previous_medoids_file
grep -v "$iterations" $initial_medoids_file > $previous_medoids_file

for ((iter=1; iter<=iterations; iter++))
do
    echo "Iteration $iter of $iterations started..." | tee -a $log_output

    # Removing existing Hadoop output directory, if it exists
    if hadoop fs -test -d /Output/Task2; then
        echo "Cleaning up old /Output/Task3 directory..." | tee -a $log_output
        hadoop fs -rm -r /Output/Task2
    fi

    medoids_source=$initial_medoids_file
    if [ $iter -gt 1 ]; then
        medoids_source=$new_medoids_file
    fi

    echo "Current medoids for iteration $iter:" >> $log_output
    cat $medoids_source | grep -v "$iterations" >> $log_output


    hadoop jar ./hadoop-streaming-3.1.4.jar \
        -files /home/hadoop/task2_mapper.py,/home/hadoop/task2_reducer.py,$medoids_source \
        -mapper "python3 task2_mapper.py $medoids_source" \
        -reducer "python3 task2_reducer.py" \
        -input /Input/Trips.txt \
        -output /Output/Task2

    # Checking if MapReduce job was successful
    if [ $? -ne 0 ]; then
        echo "MapReduce job failed in iteration $iter." | tee -a $log_output
        exit 1
    fi


    echo "$iterations" > $new_medoids_file

    # Fetching new medoids from Hadoop output
    hadoop fs -cat /Output/Task2/part-000* | grep -Eo '^[^ ]+' >> $new_medoids_file


    sort -u "$new_medoids_file" -o "$new_medoids_file"

    echo "Updated medoids after iteration $iter:" >> $log_output
    cat $new_medoids_file | grep -v "$iterations" >> $log_output
    echo "--------------------------------------" >> $log_output

    # Checking for convergence: compare old medoids to new ones
    old_medoids=$(grep -v "$iterations" "$previous_medoids_file" | tr -d '[:space:]')
    new_medoids=$(grep -v "$iterations" "$new_medoids_file" | tr -d '[:space:]')

    if [ "$old_medoids" == "$new_medoids" ]; then
        echo "Convergence achieved at iteration $iter." | tee -a $log_output
        break
    else
        echo "Medoids updated; proceeding to the next iteration..." | tee -a $log_output
        cp $new_medoids_file $previous_medoids_file  # Update the previous medoids file
    fi
done

# Saving the final medoids after iterations complete
echo "Final medoids saved to $final_medoids_output..." | tee -a $log_output
hadoop fs -cat /Output/Task2/part-000* | grep -Eo '^[^ ]+' | sort -u | head -n 3 >> $final_medoids_output

echo "Clustering completed. Final medoids written to $final_medoids_output." | tee -a $log_output


