#!/usr/bin/env python3
import sys

# Lists to store unique taxi ID, their trip counts, and corresponding company ID
taxi_ids = []
trip_counts = []
company_ids = []

for entry in sys.stdin:
    entry = entry.strip()

    if not entry:
        continue

    # Splitting the input line into a key and value
    try:
        taxi_id, record = entry.split('\t', 1)
        record_type, record_data = record.split(',', 1)
    except ValueError:
        continue

    if record_type == 'TRIP':
        if taxi_id in taxi_ids:
            index = taxi_ids.index(taxi_id)
            trip_counts[index] += int(record_data)
        else:
            taxi_ids.append(taxi_id)
            trip_counts.append(int(record_data))
            company_ids.append(None)  # Placeholder for company ID

    elif record_type == 'COMPANY':
        if taxi_id in taxi_ids:
            index = taxi_ids.index(taxi_id)
            company_ids[index] = record_data
        else:
            taxi_ids.append(taxi_id)
            trip_counts.append(0)  # No trips yet
            company_ids.append(record_data)

for i in range(len(taxi_ids)):
    if company_ids[i] is not None:
        print(f"{company_ids[i]}\t{trip_counts[i]}")
