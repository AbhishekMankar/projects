#!/usr/bin/env python3
import sys

trip_records = []

for record in sys.stdin:
    # Removeing any Byte Order Mark (BOM) and trim unnecessary whitespace
    record = record.lstrip('\ufeff').strip()

    # Cleaning the line by removing any characters that aren't alphanumeric, spaces, tabs, or commas
    record = ''.join(char for char in record if char.isalnum() or char in ' \t,')

    # Skipping empty or invalid lines
    if not record:
        continue

    data_fields = record.split()
    
    # Ensuring the line has exactly two parts
    if len(data_fields) != 2:
        print(f"Error processing line: Unexpected format: {record}", file=sys.stderr)
        continue

    # Extracting total trips and company ID and remove any surrounding whitespace
    trip_count = data_fields[0].strip()
    taxi_company = data_fields[1].strip()

    try:
        trip_records.append((int(trip_count), taxi_company))
    except ValueError:
        print(f"Error processing line: {record}", file=sys.stderr)
        continue

trip_records.sort()

for trip_count, taxi_company in trip_records:
    print(f"{taxi_company},{trip_count}")
