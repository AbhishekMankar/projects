#!/usr/bin/env python3
import sys

for x in sys.stdin:
    # Removeing whitespace from the input line
    x = x.strip()

    # Skipping the header line that starts with 'Trip#'
    if x.startswith('Trip#'):
        continue

    # Splitting the input line into components using commas
    fields = x.split(',')

    # Ensuring the input line has exactly 8 fields
    if len(fields) != 8:
        continue

    # Extracting the trip ID and taxi ID
    trip_id = fields[0].strip()
    taxi_identifier = fields[1].strip()

    try:

        trip_fare = float(fields[2].strip())
        trip_distance = float(fields[3].strip())

        # Classifying trip based on distance
        if trip_distance >= 200:
            trip_category = 'long'    # Long-distance trip
        elif trip_distance >= 100:
            trip_category = 'medium'  # Medium-distance trip
        else:
            trip_category = 'short'   # Short-distance trip

        # Emitting key-value pairs: taxi_id, trip_category as the key, and trip data as the value
        print(f"{taxi_identifier},{trip_category}\t1,{trip_fare:.2f},{trip_fare:.2f},{trip_fare:.2f}")

    except ValueError:
        continue
