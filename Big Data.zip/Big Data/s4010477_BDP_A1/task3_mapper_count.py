#!/usr/bin/env python3
import sys  

for input_line in sys.stdin:
    input_line = input_line.strip()
   
    if not input_line:
        continue

    # Splitting the line into company_id and trip_count
    company_id, trip_count = input_line.split('\t')
    
    print(f"{company_id}\t{trip_count}")
