#!/usr/bin/env python3

import sys
import math

# Function to check if the user has provided the correct medoid file path
def check_file_argument():
    if len(sys.argv) != 2:
        print("Error: You need to specify the path to the medoid file", file=sys.stderr)
        sys.exit(1)

# Function to read medoid points from the given file
def read_medoids_from_file(file_path):
    medoid_list = []
    try:
        with open(file_path, 'r') as file:
            # Skip the first line which contains the number of iterations
            lines = file.readlines()[1:]
            for line in lines:
                x, y = map(float, line.strip().split())
                medoid_list.append((x, y))
    except Exception as e:
        print(f"Error: Could not read the medoid file - {e}", file=sys.stderr)
        sys.exit(1)
    return medoid_list

# Function to calculate the Euclidean distance between two points
def compute_distance(point1, point2):
    delta_x = point1[0] - point2[0]
    delta_y = point1[1] - point2[1]
    return math.sqrt(delta_x ** 2 + delta_y ** 2)

# Function to find the closest medoid for a given dropoff point
def find_closest_medoid(dropoff_point, medoids):
    nearest_medoid = None
    smallest_distance = float('inf')
    for medoid in medoids:
        distance = compute_distance(dropoff_point, medoid)
        if distance < smallest_distance:
            smallest_distance = distance
            nearest_medoid = medoid
    return nearest_medoid, smallest_distance

# function to process input data and map trips to their closest medoid
def process_input_data(medoids):
    for line in sys.stdin:
        try:
            fields = line.strip().split(',')
            if len(fields) == 8:
                trip_id = fields[0]
                dropoff_longitude = float(fields[4])
                dropoff_latitude = float(fields[5])

                # closest medoid for the current dropoff point
                medoid, distance = find_closest_medoid((dropoff_longitude, dropoff_latitude), medoids)

                print(f"{medoid[0]},{medoid[1]}\t{trip_id},{dropoff_longitude},{dropoff_latitude},{distance}")

        except Exception as e:
            print(f"Error: Failed to process line {line} - {e}", file=sys.stderr)

if __name__ == "__main__":
    check_file_argument()
    medoid_file_path = sys.argv[1]
    medoid_points = read_medoids_from_file(medoid_file_path)
    process_input_data(medoid_points)
