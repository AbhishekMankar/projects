#!/usr/bin/env python3
import sys

# Function to calculate the Euclidean distance between two points
def euclidean_distance(p1_x, p1_y, p2_x, p2_y):
    # Convert input coordinates to float and compute the distance
    return ((float(p1_x) - float(p2_x)) ** 2 + (float(p1_y) - float(p2_y)) ** 2) ** 0.5

# Function to compute the average dissimilarity of medoid 
def compute_avg_dissimilarity(candidate, data_points):
    total_distance = sum(euclidean_distance(candidate[0], candidate[1], point[0], point[1]) for point in data_points)
    return total_distance / len(data_points) if data_points else float('inf')

# Function to select the best medoid by evaluating each point
def select_best_medoid(current, data_points):
    lowest_cost = float('inf')
    best_choice = current

    for point in data_points + [current]:
        # Computing the cost of this point as a potential new medoid
        cost = compute_avg_dissimilarity(point, data_points)
        # Update the best choice if this point has a lower cost
        if cost < lowest_cost:
            lowest_cost = cost
            best_choice = point

    return best_choice

def reduce_input():
    current_medoid = None
    cluster_points = []

    for input_line in sys.stdin:
        try:
            medoid_key, point_info = input_line.strip().split("\t")
            trip_id, dropoff_x, dropoff_y, _ = point_info.split(",")

            medoid_coords = tuple(map(float, medoid_key.split(',')))

            # If there's an existing medoid and it's different from the current one
            if current_medoid and current_medoid != medoid_coords:
                # Find the best medoid for the cluster points
                best_medoid = select_best_medoid(current_medoid, cluster_points)
                print(f"{best_medoid[0]}\t{best_medoid[1]}")
                # Reset the cluster points for the new medoid
                cluster_points = []
                current_medoid = medoid_coords

            # Updating the current medoid and add the current point to the list
            current_medoid = medoid_coords
            cluster_points.append((float(dropoff_x), float(dropoff_y)))

        except Exception as error:
            print(f"Error processing line: {input_line} - {error}", file=sys.stderr)

    # After processing all input lines, find and output the best medoid for the last cluster
    if current_medoid:
        best_medoid = select_best_medoid(current_medoid, cluster_points)
        print(f"{best_medoid[0]}\t{best_medoid[1]}")

if __name__ == "__main__":
    reduce_input()
