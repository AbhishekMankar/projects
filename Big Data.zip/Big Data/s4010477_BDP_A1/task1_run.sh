#!/bin/bash
hadoop jar ./hadoop-streaming-3.1.4.jar \
-D mapreduce.job.output.key.comparator.class=org.apache.hadoop.mapred.lib.KeyFieldBasedComparator \
-D mapreduce.partition.keycomparator.options="-k1,1n" \
-D mapred.reduce.tasks=3 \
-file ./task1_mapper.py \
-mapper ./task1_mapper.py \
-file ./task1_reducer.py \
-reducer ./task1_reducer.py \
-input /Input/Trips.txt \
-output /Output/Task1
