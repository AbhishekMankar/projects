#!/bin/bash

# Defining directories for final outputs
JOIN_OUTPUT_DIR="/tmp/join_results"
COUNT_OUTPUT_DIR="/tmp/count_results"
FINAL_OUTPUT_DIR="/Output/Task3"

# Deleting the files if they already exist
hadoop fs -rm -r $JOIN_OUTPUT_DIR
hadoop fs -rm -r $COUNT_OUTPUT_DIR
hadoop fs -rm -r $FINAL_OUTPUT_DIR

# Join operation between the two input files 
hadoop jar ./hadoop-streaming-3.1.4.jar \
  -D mapred.reduce.tasks=3 \
  -input /Input/Taxis.txt \
  -input /Input/Trips.txt \
  -output $JOIN_OUTPUT_DIR \
  -file ./task3_mapper_join.py \
  -mapper ./task3_mapper_join.py \
  -file ./task3_reducer_join.py \
  -reducer ./task3_reducer_join.py

# Checking if the join operation was successful
if [ $? -eq 0 ]; then
  # Counting the number of trips per taxi company
  hadoop jar ./hadoop-streaming-3.1.4.jar \
    -D mapred.reduce.tasks=3 \
    -input $JOIN_OUTPUT_DIR \
    -output $COUNT_OUTPUT_DIR \
    -file ./task3_mapper_count.py \
    -mapper ./task3_mapper_count.py \
    -file ./task3_reducer_count.py \
    -reducer ./task3_reducer_count.py

  # Checking if the counting operation was successful
  if [ $? -eq 0 ]; then
    # Sorting the taxi companies by the total number of trips in ascending order
    hadoop jar ./hadoop-streaming-3.1.4.jar \
      -D mapred.reduce.tasks=3 \
      -input $COUNT_OUTPUT_DIR \
      -output $FINAL_OUTPUT_DIR \
      -file ./task3_mapper_sort.py \
      -mapper ./task3_mapper_sort.py \
      -file ./task3_reducer_sort.py \
      -reducer ./task3_reducer_sort.py

    # Verifying if the sorting step was successful
    if [ $? -eq 0 ]; then
      echo "All MapReduce jobs completed successfully."
    else
      echo "Error: Sorting job failed. Exiting..."
      exit 1
    fi

  else
    echo "Error: Counting job failed. Exiting..."
    exit 1
  fi

else
  echo "Error: Join job failed. Exiting..."
  exit 1
fi
