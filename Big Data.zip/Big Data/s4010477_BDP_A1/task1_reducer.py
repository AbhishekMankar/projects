#!/usr/bin/env python3

import sys

# Dictionary to store aggregated data for each taxi-trip type combination
aggregated_data = {}


for input_line in sys.stdin:
    input_line = input_line.strip()  

    if not input_line:
        # Skipping empty lines
        continue

    # Splitting the input line and the values
    taxi_key, values = input_line.split('\t')
    value_parts = values.split(',')

    if len(value_parts) != 4:      # If the number of fields in the values part is not 4, skipping this line

        continue

    trip_count = int(value_parts[0].strip())
    total_fare = float(value_parts[1].strip())
    min_trip_fare = float(value_parts[2].strip())
    max_trip_fare = float(value_parts[3].strip())

    # If the taxi_key is not already in the aggregated_data dictionary, initializing it with default values
    if taxi_key not in aggregated_data:
        aggregated_data[taxi_key] = {
            'total_trips': 0,
            'fare_sum': 0.0,
            'min_fare': float('inf'),    # Initialize to a very high value
            'max_fare': float('-inf')    # Initialize to a very low value
        }

    # Updating the values in the aggregated_data dictionary for the current taxi_key
    aggregated_data[taxi_key]['total_trips'] += trip_count
    aggregated_data[taxi_key]['fare_sum'] += total_fare
    aggregated_data[taxi_key]['min_fare'] = min(aggregated_data[taxi_key]['min_fare'], min_trip_fare)
    aggregated_data[taxi_key]['max_fare'] = max(aggregated_data[taxi_key]['max_fare'], max_trip_fare)


for taxi_key, metrics in aggregated_data.items():
    taxi_id, trip_type = taxi_key.split(',')  # Split the key into taxi ID and trip type
    total_trips = metrics['total_trips']
    avg_fare = metrics['fare_sum'] / total_trips  # Calculate average fare
    min_fare = metrics['min_fare']
    max_fare = metrics['max_fare']

    print(f"{taxi_id},{trip_type},{total_trips},{max_fare:.2f},{min_fare:.2f},{avg_fare:.2f}")
