#!/usr/bin/env python3
import sys

for input_line in sys.stdin:
    input_line = input_line.strip()

    # Skipping empty lines
    if not input_line:
        continue

    fields = input_line.split(',')

    # Checking if the line belongs to Taxis.txt and it has 4 columns
    if len(fields) == 4:
        taxi_identifier, company_identifier, car_model, car_year = fields
        print(f"{taxi_identifier}\tCOMPANY,{company_identifier}")

    # Checking if the line belongs to Trips.txt and has 8 columns
    elif len(fields) == 8:
        trip_identifier, taxi_identifier, trip_fare, trip_distance, start_x, start_y, end_x, end_y = fields
        print(f"{taxi_identifier}\tTRIP,1")
