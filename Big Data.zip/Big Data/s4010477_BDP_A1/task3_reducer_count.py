#!/usr/bin/env python3
import sys

# Initializing List to store 
company_trip_counts = []

for input_line in sys.stdin:
    input_line = input_line.strip()

    if not input_line:
        continue

    # Splitting the line into company ID and trip count
    company_identifier, trip_count = input_line.split('\t')
    trip_count = int(trip_count)

    # Checking if the company identifier is already in the list or not
    found = False
    for i in range(len(company_trip_counts)):
        if company_trip_counts[i][0] == company_identifier:
            # Updating the total trip count for company
            company_trip_counts[i] = (company_identifier, company_trip_counts[i][1] + trip_count)
            found = True
            break
    
    if not found:
        # Adding new company identifier with trip count
        company_trip_counts.append((company_identifier, trip_count))

for company_identifier, total_trips in company_trip_counts:
    print(f"{company_identifier},{total_trips}")
