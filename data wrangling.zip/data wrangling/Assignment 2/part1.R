install.packages("tidyr")
install.packages("dplyr")
library(tidyr)
library(magrittr)
# Have used this library to enable piping functions.
library(dplyr)
library(readr)

AI_data <- read_csv("F:/Data Wrangling/Assignment 2/Practical Assessment 2_Rmarkdown_Template.nb/Data/AI_Data/AI_index_db.csv")
View(AI_data)

Internet_data <- read_csv("F:/Data Wrangling/Assignment 2/Practical Assessment 2_Rmarkdown_Template.nb/Data/Internet_Usage/gapminder_internet.csv")
View(Internet_data)

temp_df <- data.frame(
  country_AI = AI_data$Country
)
# Created a temporary data frame storing all countries data from the 'Country' column of the Global AI Index data

temp_df$check <- temp_df$country_AI %in% Internet_data$country

# Verifying whether the country data from the AI Index data set is present in the 'country' column of the Internet Usage data set.
# This verification is crucial as the existence of data in the 'country' column of the AI Index data set is necessary for the 
# subsequent merging of these data sets based on these shared columns.

filter(temp_df, check == "FALSE")
# Using the filter() method to view filtered data of countries from the AI Index data which were not found in the Internet Usage data

is_united_present <- grepl("united", Internet_data$country, ignore.case = TRUE) ################ N1 #################
# Checking if there are any entries in the 'country' column of Internet Usage data where data consists an instance of "united" in it.
print(Internet_data[is_united_present, ])
# Printing data points with instances of "united" string in them
Internet_data$country[Internet_data$country == "United States"] <-  "United States of America"
# Replacing entry for the data points which correspond to "United States of America", now matching with data in the AI Index data set. 

# Performing similar cleaning for all other instances found
is_united_present <- grepl("korea", Internet_data$country, ignore.case = TRUE)
(Internet_data[is_united_present, ])
Internet_data$country[Internet_data$country == "Korea, Rep."] <-  "South Korea"

is_united_present <- grepl("nether", Internet_data$country, ignore.case = TRUE)
(Internet_data[is_united_present, ])
Internet_data$country[Internet_data$country == "Netherlands"] <-  "The Netherlands"

is_united_present <- grepl("kong", Internet_data$country, ignore.case = TRUE)
(Internet_data[is_united_present, ])
Internet_data$country[Internet_data$country == "Hong Kong, China"] <-  "Hong Kong"

is_united_present <- grepl("cz", Internet_data$country, ignore.case = TRUE)
(Internet_data[is_united_present, ])
Internet_data$country[Internet_data$country == "Czech Rep."] <-  "Czech Republic"

is_united_present <- grepl("slo", Internet_data$country, ignore.case = TRUE)
(Internet_data[is_united_present, ])
Internet_data$country[Internet_data$country == "Slovak Republic"] <-  "Slovakia"

temp_df$check <- temp_df$country_AI %in% Internet_data$country
filter(temp_df, check == "FALSE")
# Checking once again if there are any mismatches in the common country column in both data sets.

colnames(Internet_data) <- c("Country", "GDP per capita in US$", "Internet Users", "Urban Population")
colnames(AI_data) <- c("Country", "Talent Indicator", "Infrastructure", "Operating Environment",
                       "Research Indicator", "Development Indicator", "Government Strategy", "Commerical Indicator",
                       "Total Score", "Region", "Cluster", "Income group", "Political regime")
# Renaming the columns with appropriate headers for both data sets.

str(AI_data)
# Checking structure of the AI Index data set to check for any incorrect data types for the variables and perform require data 
# type conversions accordingly

AI_data$Region <- factor(AI_data$Region)
AI_data$Cluster <- factor(AI_data$Cluster)
AI_data$`Income group` <- factor(AI_data$`Income group`)
AI_data$`Political regime` <- factor(AI_data$`Political regime`)

str(Internet_data)
# Checking structure of the Internet Usage data set to check for any incorrect data types for the variables and perform require data 
# type conversions accordingly

summary(AI_data)
summary(Internet_data)

missing_values_AI <- sum(is.na(AI_data))
missing_values_Internet <- sum(is.na(Internet_data))

print(is.na(Internet_data$`GDP per capita in US$`))
Internet_data$`GDP per capita in US$`[is.na(Internet_data$`GDP per capita in US$`)] <- mean(Internet_data$`GDP per capita in US$`, na.rm = TRUE)
print(is.na(Internet_data$`GDP per capita in US$`))

print(is.na(Internet_data$`Internet Users`))
Internet_data$`Internet Users`[is.na(Internet_data$`Internet Users`)] <- mean(Internet_data$`Internet Users`, na.rm = TRUE)
print(is.na(Internet_data$`Internet Users`))

print(is.na(Internet_data$`Urban Population`))
Internet_data$`Urban Population`[is.na(Internet_data$`Urban Population`)] <- mean(Internet_data$`Urban Population`, na.rm = TRUE)
print(is.na(Internet_data$`Urban Population`))

boxplot(AI_data[-c(1, 10, 11, 12, 13)], outline=TRUE)

cap <- function(x){
  quantiles <- quantile( x, c(.05, 0.25, 0.75, .95 ) )
  x[ x < quantiles[2] - 1.5*IQR(x) ] <- quantiles[1]
  x[ x > quantiles[3] + 1.5*IQR(x) ] <- quantiles[4]
  x}

AI_data$`Talent Indicator` <- AI_data$`Talent Indicator` %>% cap()
AI_data$Infrastructure <- AI_data$Infrastructure %>% cap()
AI_data$`Operating Environment` <- AI_data$`Operating Environment` %>% cap()
AI_data$`Research Indicator` <- AI_data$`Research Indicator` %>% cap()
AI_data$`Development Indicator` <- AI_data$`Development Indicator` %>% cap()
AI_data$`Government Strategy` <- AI_data$`Government Strategy` %>% cap()
AI_data$`Commerical Indicator` <- AI_data$`Commerical Indicator` %>% cap()
AI_data$`Total Score` <- AI_data$`Total Score` %>% cap()

boxplot(AI_data[-c(1, 10, 11, 12, 13)], outline=TRUE)

boxplot(Internet_data[2], outline=TRUE)
boxplot(Internet_data[3], outline=TRUE)
boxplot(Internet_data[4], outline=TRUE)

Internet_data$`GDP per capita in US$` <- Internet_data$`GDP per capita in US$` %>% cap()
boxplot(Internet_data[2], outline=TRUE)

hist(AI_data$`Talent Indicator`)
sqrt_AI_Talent <- sqrt(AI_data$`Talent Indicator`)
hist(sqrt_AI_Talent)

Merged_Data <- left_join(AI_data, Internet_data)
# The AI Index data set and the Internet Usage data set have been combined using the left_join() method. The merging process
# was based on a shared variable, the 'Country' column. The resulting data set, named 'Merged_Data', contains all the records
# from the Internet Usage data set that have a corresponding match in the 'Country' column of the AI Index data set. In other
# words, only the records from the Internet Usage data set that align with existing countries in the AI Index data set have
# been retrieved and stored in the merged data set.

Merged_Data <- Merged_Data %>% mutate(Digital_Readiness_Index = (`Talent Indicator` * 0.2) + (Infrastructure * 0.2) + 
                                        (`Operating Environment` * 0.2) + (`Internet Users` * 0.2) + 
                                        (`Urban Population` * 0.2))




#talent indicator
#development indicator
#commercial indiactor


hist(Merged_Data$`Commerical Indicator`)

#We will be transforming the Commercial Indicator variable.

#From the histgram, it was evident that the data is right positive skewed.
#In order to further analyse the data, normalisation will be required.
#Thus, the overall aim of the transformation is to reduce the skewness
#and to change the scale of a variable or standardize the values of a variable for better understanding.

#Since the data is right skewed, it can be reduced via square root, logarithms or reciprocals.


#Square Root Transformation
sqrt_final<-sqrt(Merged_Data$`Commerical Indicator`)
hist(sqrt_final, main = "Histogram after Square Root transformation - Commercial Indicator")

#Reciprocal
Merged_Data$`Commerical Indicator` <- 1/Merged_Data$`Commerical Indicator`
hist(Merged_Data$`Commerical Indicator`, main = "Histogram after Reciprocal transformation - Merged_Data$`Commerical Indicator")

#Log
log_Merged_Data <- log(Merged_Data$`Commerical Indicator`)
hist(log_Merged_Data, main = "Histogram after Log transformation - Total number of Offenses",xlab = "Number of Offenses")

#Base 10 Log
log10_Merged_Data <- log10(Merged_Data$`Commerical Indicator`)
hist(log10_Merged_Data, main = "Histogram after Natural Log transformation - Total number of Offenses",xlab = "Number of Offenses")

#After applying the different transformations, a base 10 logarithm resulted in the most optimal distribution.
