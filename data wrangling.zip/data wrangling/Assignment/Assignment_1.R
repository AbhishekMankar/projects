#The 2021 Games are the fourth Olympic Games to be held in Japan, following the Tokyo 1964 (Summer), Sapporo 1972 (Winter), and Nagano 1998 (Winter) games.
#The 2021 Summer Olympics , officially the Games of the XXXII Olympiad and branded as Tokyo 2021, is an ongoing international multi-sport event being held from 23 July to 8 August 2021 in Tokyo, Japan, with some preliminary events that began on 21 July.
#More than 11,000 athletes from 200 countries took part in these Olympic Games.
#Data source: Tokyo 2021 Olympics

#We have used Tokyo olympic dataset and the source of the dataset is Kaggle.
#url: https://www.kaggle.com/datasets/stefanzivanov/olympic-games-2021-medals?resource=

#Variable Description
# Rank : It is the position of the country in olympics games 2021
# Team/NOC : Name of The Country 
# Gold Medals : Total Gold medals earned by the country
# Silver Medals : Total Silver medals earned by the country
# Bronze Medals : Total Bronze medals earned by the country
# Total : Sum of Gold, Silver and Bronze medals earned by each country
# Rank By Total : Position of Country with respect to total Medals earned
# NOCCode : Code given to Country By National Olympic Committee
# Continent :  Continent of the Country 


setwd("F:/Data Wrangling")

# Importing the dataset and saving it as a dataframe
data_set <- read.csv("Tokyo_2021_dataset v3.csv")


head(data_set)

#dim function is used to check the dimensions of the dataframe
dim(data_set)

#colnames is used to display the name of all the coloumn present in the dataframe
colnames(data_set)


#To check the levels of factor variables in a data frame in R, 
#you can use the levels() function. This function returns a character 
#vector containing the distinct levels of a factor variable

#Before using the levels() function, make sure to verify that the column you 
#are trying to access is indeed a factor variable.

#In R, you can set or create factors using the factor() function. 
#Factors are used to represent categorical data, where the data can only
#take on a limited number of distinct values or levels.


Continent_fact <- factor(data_set$Continent)
levels(Continent_fact)


#For making the subset of the dataframe
subset_dataset <- head(data_set,n=10)


#For converting the subset dataframe into matrix
matrix_dataframe <- as.matrix(subset_dataset)


#For finding the structure of the dataframe
str(data_set)




