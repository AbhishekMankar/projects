rm(list=ls())

install.packages("tinytex")
#Loading the necessary packages
install.packages("dplyr")
library(magrittr)
library(dplyr)
library(Hmisc)


#setting the seed
set.seed(123)



data1 <- data.frame(
  CustomerID = 1:100,
  Gender = sample(c("Male", "Female"), 100, replace = TRUE),
  Age = sample(100, replace = TRUE),
  DateOfBirth = sample(seq(as.Date('1970-01-01'), as.Date('2000-12-31'), by="days"), 100),
  PaymentMethod = sample(c("Credit Card", "Cash", "Mobile Payment"), 100, replace = TRUE),
  Membership = sample(c("Diamond","Platinum", "Gold", "Silver"), 100, replace = TRUE)
)


missing_rows <- sample(1:100, 0.05 * 100)
data1$Age[missing_rows] <- NA

#Introducing missing values
data1 <- data1 %>%
  mutate(Age = case_when(
    Age<18 | Age >65 ~ NA_real_,
    TRUE ~ Age
    
  ))

 

set.seed(456)

data2 <- data.frame(
  CustomerID = 1:100,
  ProductID = rnorm(100, mean = 30, sd = 5),
  ProductCategory = sample(c("Groceries", "Clothing", "Electronics"), 100, replace = TRUE),
  Amount_Spent = runif(100, min = 1, max = 100),
  StoreLocation = sample(c("QV", "Fitzroy", "Carlton","Flinders","SouthBank","Docklands"), 100, replace = TRUE),
  Date = sample(seq(as.Date('2022-01-01'), as.Date('2023-12-31'), by="days"), 100)
)

missing_rows2 <- sample(1:100, 0.05 * 100)
data2$ProductCategory[missing_rows2] <- NA



#co-related Data
#Loyalty points are depend on the amount spent on shopping
data2 %<>% 
  mutate(LoyaltyPoints = Amount_Spent/10)




#Merging data
merged_data <- merge(data1,data2,by="CustomerID",all=TRUE)




# Label and order the "Membership" factor variable
merged_data$Membership <- factor(merged_data$Membership, levels = c("Diamond","Platinum", "Gold", "Silver"))


# Check the structure of the merged dataset
str(merged_data)


# Perform data type conversions
merged_data$Age <- as.numeric(merged_data$Age)
merged_data$Amount_Spent <- as.numeric(merged_data$Amount_Spent)
merged_data$ProductCategory <- as.character(merged_data$ProductCategory)
merged_data$DateOfBirth <- as.Date(merged_data$DateOfBirth)



# Group by the 'StoreLocation' variable and calculate summary statistics for 'Amount_Spent'

summary_stats <- merged_data %>%
  group_by(StoreLocation) %>%
  summarize(
    Mean_Amount_Spent = mean(Amount_Spent, na.rm = TRUE),
    Median_Amount_Spent = median(Amount_Spent, na.rm = TRUE),
    First_Quartile = quantile(Amount_Spent, 0.25, na.rm = TRUE),
    Third_Quartile = quantile(Amount_Spent, 0.75, na.rm = TRUE),
    SD_Amount_Spent = sd(Amount_Spent, na.rm = TRUE)
  )



#Scanning all variables for missing values
is.na(merged_data$CustomerID)
is.na(merged_data$Gender)

is.na(merged_data$Age)
is.na(merged_data$DateOfBirth)
is.na(merged_data$PaymentMethod)
is.na(merged_data$Membership)
is.na(merged_data$ProductID)
is.na(merged_data$ProductCategory)
is.na(merged_data$Amount_Spent)
is.na(merged_data$StoreLocation)
is.na(merged_data$Date)
is.na(merged_data$LoyaltyPoints)




#Finding missing values in each variable using function
missing_values <- sapply(merged_data, function(x) sum(is.na(x)))
print(missing_values)



#Removing missing values from varibale "Age", and replacing it with the mean of all values
merged_data$Age[is.na(merged_data$Age)] <- mean(merged_data$Age, na.rm = TRUE) 

# Impute missing values in Store_Location with the mode (most frequent value)
merged_data$ProductCategory <- impute(merged_data$ProductCategory, fun= mode)



#Finding missing values in each variable using function
missing_values <- sapply(merged_data, function(x) sum(is.na(x)))
print(missing_values)




