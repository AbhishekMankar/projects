# Clean the environment
rm(list=ls())

set.seed(123)  # Replace 123 with any integer of your choice

# Numeric data
numeric_data <- rnorm(100, mean = 0, sd = 1)

# Character data
character_data <- sample(c("Red", "Blue", "Green"), size = 100, replace = TRUE)

# Factor data (categorical)
factor_data <- factor(
  sample(c("Category_A", "Category_B", "Category_C"), size = 100, replace = TRUE),
  levels = c("Category_A", "Category_B", "Category_C")
)

# Create a data frame
synthetic_data <- data.frame(
  ID = 1:100,
  Age = numeric_data,
  Color = character_data,
  Category = factor_data
)

# Set seed for reproducibility
set.seed(123)

# Create a date range for the dataset (e.g., one year of data)
start_date <- as.Date("2022-01-01")
end_date <- as.Date("2022-12-31")
date_range <- seq(start_date, end_date, by = "1 day")

# Create a synthetic sales dataset
sales_data <- data.frame(
  Date = sample(date_range, 1000, replace = TRUE),  # 1000 rows of random dates
  Product = sample(c("Apples", "Bananas", "Milk", "Bread", "Eggs"), 1000, replace = TRUE),  # Sample products
  Quantity = sample(1:10, 1000, replace = TRUE),  # Random quantity sold
  Price = runif(1000, 1, 10)  # Random price per unit
)

# Calculate total sales
sales_data <- sales_data %>%
  mutate(Total_Sales = Quantity * Price)

# Display the first few rows of the dataset
head(sales_data)
