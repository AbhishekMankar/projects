--D.1
SELECT
ld.location AS "Country Name (CN)",
SUM(cd.people_vaccinated) OVER (PARTITION BY ld.location ORDER BY cd.date) AS " Total Vaccinations (administered to date)" , 
cd.people_vaccinated AS "Daily Vaccinations",
cd.date AS "Date"
FROM
Location ld INNER JOIN Country_Data cd ON ld.location = cd.country
ORDER BY 
ld.location, cd.date ;

---D.2
SELECT
ld.country AS "Country",
SUM(cd.people_vaccinated + cd.people_fully_vaccinated + cd.total_boosters) AS "Cumulative Doses"
FROM
Locations_Data ld
INNER JOIN
vaccinations cd ON ld.country = cd.country
GROUP BY
ld.country
ORDER BY
SUM(cd.people_vaccinated + cd.people_fully_vaccinated + cd.total_boosters) DESC;


--D.3

SELECT
GROUP_CONCAT(DISTINCT lv.country) AS "Country",
v.vaccine AS "Vaccine Type"
FROM
vaccine v
INNER JOIN
Location_Vaccine lv ON v.vaccine = lv.vaccine
GROUP BY
v.vaccine
ORDER BY
v.vaccine;


--D.4

SELECT
ld.country AS "Country",
s.source_website AS "Source Name URL",
SUM(v.people_vaccinated + v.people_fully_vaccinated + v.total_boosters) AS "Biggest total Administered Vaccines"
FROM
Web_Data s
INNER JOIN
Locations_Data ld ON s.source_website = ld.source_website
INNER JOIN
vaccinations v ON ld.country = v.country
GROUP BY
s.source_website
ORDER BY
"Biggest total Administered Vaccines" DESC;

--D.5

SELECT strftime('%Y-%W', cd.date) AS Week,
SUM(CASE WHEN l.ISO_Code = 'AUS' THEN cd.people_fully_vaccinated ELSE 0 END) AS Australia,
SUM(CASE WHEN l.ISO_Code = 'DEU' THEN cd.people_fully_vaccinated ELSE 0 END) AS Germany,
SUM(CASE WHEN l.ISO_Code = 'OWID_ENG' THEN cd.people_fully_vaccinated ELSE 0 END) AS England,
SUM(CASE WHEN l.ISO_Code = 'FRA' THEN cd.people_fully_vaccinated ELSE 0 END) AS France
FROM Country_Data cd
JOIN Location l ON cd.country = l.location
WHERE strftime('%Y', cd.date) IN ('2021', '2022')
GROUP BY Week
ORDER BY Week;





