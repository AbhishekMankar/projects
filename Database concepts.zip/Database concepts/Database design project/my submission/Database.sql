CREATE TABLE Age_Groups (
age_group_id INTEGER NOT NULL,
age_group VARCHAR(20) NOT NULL,
PRIMARY KEY (age_group_id)
);



CREATE TABLE Vaccine (
vaccine VARCHAR(40) NOT NULL,
PRIMARY KEY (vaccine)
);



CREATE TABLE Location (
location STRING(40) NOT NULL,
ISO_code NOT NULL,
PRIMARY KEY (location)
);



CREATE TABLE Web_Data(
source_name STRING (40) NOT NULL,
source_website VARCHAR(100) NOT NULL,
PRIMARY KEY (source_website)
);



CREATE TABLE Country_State(
state STRING (40) NOT NULL,
country STRING(40) NOT NULL,
PRIMARY KEY (state)
);



CREATE TABLE Location_Vaccine(
country STRING (40) NOT NULL,
vaccine VARCHAR(40) NOT NULL,
PRIMARY KEY (country, vaccine),
FOREIGN KEY (country) REFERENCES Location(location)
FOREIGN KEY (vaccine) REFERENCES Vaccine(vaccine)
);



CREATE TABLE Locations_Data(
country STRING (40) NOT NULL,
last_obs_date DATE NOT NULL,
source_website VARCHAR (30) NOT NULL,
PRIMARY KEY (country),
FOREIGN KEY (country) REFERENCES Location(location),
FOREIGN KEY (source_website) REFERENCES Web_Data(source_website)
);



CREATE TABLE Vaccine_by_Age(
country STRING (40) NOT NULL,
date DATE NOT NULL,
age_group_id INTEGER NOT NULL,
people_vacc_hundred FLOAT,
people_fully_vacc_hundred FLOAT,
people_with_boosters_hundred FLOAT,
PRIMARY KEY (country, date, age_group_id),
FOREIGN KEY (country) REFERENCES Location(location),
FOREIGN KEY (age_group_id) REFERENCES Age_Groups(age_group_id)
);



CREATE TABLE Country_Data(
country STRING NOT NULL,
date DATE NOT NULL,
vaccine VARCHAR(30) NOT NULL,
SOURCE_url varhcar(100),
total_vaccination INTEGER,
people_vaccinated INTEGER,
people_fully_vaccinated INTEGER,
total_boosters INTEGER,
PRIMARY KEY (country, date, vaccine),
FOREIGN KEY (country) REFERENCES Location(location)
);



CREATE TABLE vaccinations(
country STRING NOT NULL,
date DATE NOT NULL,
people_vaccinated INTEGER,
people_fully_vaccinated INTEGER,
total_boosters INTEGER,
daily_vaccinations INTEGER,
daily_people_vaccinated INTEGER,
PRIMARY KEY (country, date)
);



CREATE TABLE Vaccination_by_manufacturer(
country STRING NOT NULL,
date DATE NOT NULL,
vaccine VARCHAR(30) NOT NULL,
total_vaccination INTEGER,
PRIMARY KEY (country, date, vaccine)
);



CREATE TABLE Country_State_Vaccination(
date DATE NOT NULL,
state STRING NOT NULL,
total_distributed INTEGER,
people_vaccinated INTEGER,
people_fully_vaccinated INTEGER,
daily_vaccinations INTEGER,
total_boosters INTEGER,
PRIMARY KEY (state, date),
FOREIGN KEY (state) REFERENCES Country_State(state)
);
