# Name :  Abhishek Dnyandeo Mankar
# Student ID : s4010477
# Assignment 2 


# About Programm:
#----------------------------------------------------------------------------------------------------------------------
# The code defines several classes to manage information related to customers, locations, rates, services, and bookings.
# These classes allow you to store, retrieve, and manipulate data related to a customer.
# There is error handling for cases where files are not found, and methods are provided to update customer information, rate information, and enterprise customer discount rates.
# The whole programm is divided into many Classes , the object of the classes are used to use the particular class.
# Overall, this code is designed to manage data for a taxi management service, allowing you to maintain information about customers, locations, rates, services, and bookings, and perform various operations on this data.
# It provides a structured approach to organizing and working with this information.
# The Programm is menu driven and all the options in the menu gives the respected response.




# Challenges faced:
#--------------------------------------------------------------------------------------------------------------------
# Reading the services.txt file , as the packages have values based on the services.
# reading the bookings.txt file , as input for every customer booking history have different history format ,ex:destination are multiple for some customers and services are not used by # #some customers.







import sys
# Defining Class Customer
class Customer:
    def __init__(self, ID, name):  # Constructor taking the values of ID, name as arguments
        self.ID = ID
        self.name = name

    def get_ID(self):  # getter method for ID of the customer
        return self.ID

    def get_name(self):  # getter method for name of the customer
        return self.name

    def get_discount(self):  # get_discount which is an empty super method
        pass

    def display_info(self):  # display_info which is an empty super method
        pass


# Defining Class BasicCustomer
class BasicCustomer(Customer):  # Inherit from Customer

    def __init__(self, ID, name, discount_rate=0.10):
        super().__init__(ID, name)
        self.discount_rate = discount_rate

    def get_discount_rate(self):
        return self.discount_rate

    # @classmethod decorator is a built-in function decorator which is an expression that gets evaluated after your function is defined

    @classmethod
    def set_discount_rate(self, discount_rate):
        self.discount_rate = discount_rate

    def get_discount(self, distance_fee):
        return self.discount_rate * distance_fee

    def display_info(self):
        print("Customer ID:", self.ID)
        print("Customer Name:", self.name)
        print("Discount Rate:", f"{self.discount_rate * 100}%")


    # # @classmethod decorator is a built-in function decorator which is an expression that gets evaluated after your function is defined
    # @classmethod
    # def set_discount_rate(cls, new_discount_rate):  # method to adjust the discount rate.
    #     cls.discount_rate = new_discount_rate


# Defining class Enterprisecustomer
class EnterpriseCustomer(Customer):
    def __init__(self, ID, name, rate1=0.15, rate2=0.20, threshold=100):
        super().__init__(ID, name)
        self.rate1 = rate1
        self.rate2 = rate2
        self.threshold = threshold

    def get_rate1(self):
        return self.rate1

    def get_rate2(self):
        return self.rate2

    def get_threshold(self):
        return self.threshold

    def set_discount_rates(self, rate1, rate2):
        self.rate1 = rate1
        self.rate2 = rate2

    @classmethod
    def set_threshold(self, threshold):
        self.threshold = threshold

    def get_discount(self, distance_fee):
        if distance_fee < self.threshold:
            return self.rate1 * distance_fee
        else:
            return self.rate2 * distance_fee

    def display_info(self):
        print("Customer ID:", self.ID)
        print("Customer Name:", self.name)
        print("Rate 1:", f"{self.rate1 * 100}%")
        print("Rate 2:", f"{self.rate2 * 100}%")
        print("Threshold:", f"${self.threshold}")


# Defining class location
class Location:
    def __init__(self, location_id, name, address):
        self.location_id = location_id
        self.name = name
        self.address = address

    def display_info(self):  # display_info() method prints the values of the Location attributes.
        print(f"Location ID: {self.location_id}")
        print(f"Location Name: {self.name}")
        print(f"Location Address: {self.address}")


# Defining class rates
class Rate:
    def __init__(self, rate_id, name, price_per_km):
        self.rate_id = rate_id
        self.name = name
        self.price_per_km = price_per_km

    def display_info(self):  # display_info() method prints the values of the Rate attributes.
        print("Rate ID:", self.rate_id)
        print("Rate Type:", self.name)
        print("Price per km:", self.price_per_km)


# Defining class Booking
class Booking:
    def __init__(self, customer, departure, destination, rate, distance,discount,service_fee):
        self.customer = customer
        self.departure = departure
        self.destination = destination
        self.distance = distance
        self.rate = rate
        self.discount=discount
        self.service_fee=service_fee

    def get_customer(self):
        return self.customer

    def get_departure(self):
        return self.departure

    def get_destination(self):
        return self.destination

    def get_distance(self):
        return self.distance

    def get_rate(self):
        return self.rate

    def compute_cost(self):           #Computing the total price for booking
        total_distance=0
        for item in self.distance:
            total_distance += item

        distance_fee = total_distance * self.rate
        basic_fee = 4.2
        discount = distance_fee * self.discount

        #if self.service:
         #   service_fee = self.service.get_price()

        total_cost = basic_fee + distance_fee - discount + self.service_fee
        return round(distance_fee, 2), round(basic_fee, 2), round(discount, 2), round(total_cost, 2), round(self.service_fee, 2)


# Define the BookingRecord class to represent a single booking record
class BookingRecord:
    def __init__(self, customer, departure, destinations, distances, rate_type, service, basic_fee, distance_fee, discount, total_cost):
        self.customer = customer
        self.departure = departure
        self.destinations = destinations
        self.distances = distances
        self.rate_type = rate_type
        self.service = service
        self.basic_fee = basic_fee
        self.distance_fee = distance_fee
        self.discount = discount
        self.total_cost = total_cost




# Defining class Records
class Records:
    def __init__(self):
        self.customers = []  # List for existing customers
        self.locations = []  # List for existing locations
        self.rates = []  # List for existing rate types
        self.services = []  # List to store services and packages
        self.bookings = []  #List for existing bookings


    # this method is used to add the new rate type to existing rate types
    def add_rate_type(self, rate_name, price_per_km):
        size_of_rates_list=len(self.rates)+1
        rate_id="R"+str(size_of_rates_list)
        self.rates.append((rate_id,rate_name, price_per_km))


    # this method is used is used to update the existing rate types
    def update_rate_type_price(self, rate_name, new_price_per_km):
        for i, rate in enumerate(self.rates):
            if rate[1] == rate_name:
                self.rates[i] = (rate[0],rate_name, new_price_per_km)
                break

    # this method is used to read the booking file , which have booking history of existing customers
    def read_bookings(self, filename):
        try:
            with open(filename, 'r') as file:
                for line in file:
                    booking_data = line.strip().split(', ')
                    customer, departure = booking_data[:2]
                    rate_type, service, basic_fee, distance_fee, discount, total_cost = booking_data[-6:]

                    # Determine the number of destinations and distances
                    num_destinations = (len(booking_data) - 6) // 2
                    destinations = booking_data[2:2 + num_destinations]
                    distances = list(map(float, booking_data[2 + num_destinations:-6]))

                    # Create a BookingRecord object and add it to the bookings list
                    booking_record = BookingRecord(customer, departure, destinations, distances,
                                                   rate_type, service, float(basic_fee), float(distance_fee),
                                                   float(discount), float(total_cost))
                    self.bookings.append(booking_record)
        except FileNotFoundError:
            print("Cannot load the booking file.")
        except Exception as e:
            print(f"An error occurred while reading the booking file: {str(e)}")


    #this method is used to update the discount rate of enterprise customer
    # it takes two arguments from adjust_enterprise_customer_discount() and update discount rate
    def update_enterprise_customer_discount(self, customer_id, new_discount_rate):
        updated_customers = []
        found = False

        for customer in self.customers:
            if customer[0] == customer_id and customer[2] == 'E':
                updated_customer = (customer[0], customer[1], customer[2], new_discount_rate, customer[4])
                updated_customers.append(updated_customer)
                found = True
            else:
                updated_customers.append(customer)

        if found:
            self.customers = updated_customers
            print(f"Discount rate for Enterprise customer with ID {customer_id} updated to {new_discount_rate * 100}%")
        else:
            print("Enterprise customer not found with the specified ID.")



    # read_customers() is used to read the customers.txt file and extract the information from in it
    def read_customers(self,
                       filename):
        with open(filename, 'r') as file:
            for line in file:
                customer_data = line.strip().split(', ')
                customer_id, name, customer_type = int(customer_data[0]), customer_data[1], customer_data[2]
                if customer_type == 'B':
                    discount_rate = float(customer_data[3])
                    customer = (customer_id, name, customer_type, discount_rate)                             #creating the object for basic customer
                elif customer_type == 'E':
                    discount_rate, threshold = float(customer_data[3]), int(customer_data[4])
                    customer = (customer_id, name, customer_type, discount_rate, threshold)                  #creating the object for enterprise customer
                self.customers.append(customer)

    # read_locations() is used to read the locations.txt file and extract the information from in it
    def read_locations(self,
                       filename):
        with open(filename, 'r') as file:
            for line in file:
                location_id, location_name = line.strip().split(', ')
                self.locations.append((location_id,location_name))



    # read_rates() is used to read the rates.txt file and extract the information from in it
    def read_rates(self,
                   filename):  # read_rates() takes input as a file name and store all the rate types present in the file in self.rates
        with open(filename, 'r') as file:
            for line in file:
                rate_id, rate_name, price_per_km = line.strip().split(', ')
                self.rates.append((rate_id, rate_name, float(price_per_km)))
                #self.rates.append((rate_name))


    # read_services_file() is used to read the services.txt file and extract the information from in it
    def read_services_file(self, file_name):
        try:
            with open(file_name, 'r') as file:
                file_contents = file.read()
                lines = file_contents.split('\n')

                for line in lines:
                    parts = line.strip().split(', ')
                    if parts[0].startswith('S'):
                        # It's a service
                        service_id, service_name, service_price = parts
                        self.services.append({
                            'type': 'service',
                            'ID': service_id,
                            'Name': service_name,
                            'Price': float(service_price)
                        })
                    elif parts[0].startswith('P'):
                        # It's a package
                        package_id, package_name, *service_ids = parts         #Diaz, D. (2023) How to use the Unpacking Operators (*, **) in python?, Geekflare. Available at: https://geekflare.com/python-unpacking-operators/ (Accessed: 13 October 2023).
                        package_services = [s_id for s_id in service_ids]
                        self.services.append({
                            'type': 'package',
                            'ID': package_id,
                            'Name': package_name,
                            'services': package_services
                        })

        except FileNotFoundError:
            print(f"Error: File {file_name} not found.")
        except Exception as e:
            print(f"An error occurred while reading the file: {str(e)}")


    def add_service(self, service):
        self.services.append(service)


    def find_customer(self, search_value):
        for customer in self.customers:
            if search_value in customer:
                return customer
        return None

    def find_location(self, search_value):
        for location in self.locations:
            if search_value in location:
                return location
        return None

    def find_rate(self, search_value):
        for rate in self.rates:
            if search_value in rate:
                return rate
        return None


    def find_service_by_id(self, service_id):
        for service in self.services:
            if service.get_service_id() == service_id:
                return service
        return None


    # list_customers is used to print the customers
    def list_customers(self):
        for customer in self.customers:
            if customer[2] == 'B':
                print(
                    f"Customer ID: {customer[0]}, Name: {customer[1]}, Type: {customer[2]}, Discount Rate: {customer[3]}")
            elif customer[2] == 'E':
                print(
                    f"Customer ID: {customer[0]}, Name: {customer[1]}, Type: {customer[2]}, Discount Rate: {customer[3]}, Threshold: {customer[4]}")


    # list_locations is used to print the locations
    def list_locations(self):
        for location in self.locations:
            print(f"Location ID: {location[0]}, Name: {location[1]}")

    # list_rates is used to print the rate types
    def list_rates(self):
        for rate in self.rates:
            print(f"Rate ID: {rate[0]}, Name: {rate[1]}, Price per km: {rate[2]}")

    # list_services is used to print the available services
    def list_services(self):
        for service in self.services:
            print(service)




#This class is to keep track of information of different extra services
class Service:
    def __init__(self, service_id, name, price):
        self.service_id = service_id  # Unique identifier for the service (e.g., S1, S2, etc.)
        self.service_name = name  # Name of the service (e.g., Internet, Snack, Drink, Entertainment, etc.)
        self.service_price = price  # Price of the service

    def get_service_id(self):
        return self.service_id

    def get_name(self):
        return self.service_name

    def get_price(self):
        return self.service_price

    def set_price(self, new_price):   #The set_price() method allows you to change the price of the service.
        self.price = new_price

    def __str__(self):
        return f"Service ID: {self.service_id}, Name: {self.service_name}, Price: {self.service_price}"



#This class is to keep track of information of different extra packages
class Package:
    def __init__(self, package_id, package_name, package_services):
        self.package_id = package_id  # Unique identifier for the package (e.g., P1, P2, etc.)
        self.package_name = package_name  # Name of the package (e.g., Starter, Deluxe, etc.)
        self.package_services = package_services  # List of services included in the package

    def get_package_id(self):
        return self.package_id

    def get_name(self):
        return self.package_name

    def get_services(self):
        return self.package_services

    # The calculate_price() method calculates the price of the package based on the prices of the component services.
    # It checks if there are at least 2 services in the package and calculates the price as 80% of the total price of the component services.
    def calculate_price(self):
        if len(self.package_services) < 2:
            return None  # A package must have at least 2 services
        total_price = sum(service.get_price() for service in self.package_services)
        return 0.8 * total_price  # 80% of the total price of component services


# Defining class operations
class Operations:
    def __init__(self):
        self.records = Records()  # creating object of Records class
       # self.basic = BasicCustomer()

    def save_data(self):
        # Saving customers data to customers.txt file
        with open("customers.txt", "w") as customers_file:
            for customer in self.records.customers:
                customers_file.write(", ".join(map(str, customer)) + "\n")    # Reference -> (No date a) Python map() function. Available at: https://www.w3schools.com/python/ref_func_map.asp (Accessed: 15 October 2023).

        # Saving locations data to locations.txt
        with open("locations.txt", "w") as locations_file:
            for location in self.records.locations:
                locations_file.write(", ".join(map(str, location)) + "\n")

        # Saving rates to rates.txt
        with open("rates.txt", "w") as rates_file:
            for rate in self.records.rates:
                rates_file.write(", ".join(map(str, rate)) + "\n")

        # Saving booking history to bookings.txt
        with open("bookings.txt", "w") as bookings_file:
            for booking in self.records.bookings:
                booking_data = [
                    booking.customer,
                    booking.departure,
                    ", ".join(booking.destinations),
                    ", ".join(map(str, booking.distances)),
                    booking.rate_type,
                    booking.service,
                    str(booking.basic_fee),
                    str(booking.distance_fee),
                    str(booking.discount),
                    str(booking.total_cost),
                ]
                bookings_file.write(", ".join(booking_data) + "\n")

    # Load_data() is used to load all the files through command line arguments
    def load_data(self, args):
        if len(args) == 1:
            # if no command-line arguments are provided,then use default file names
            customer_file = "customers.txt"
            location_file = "locations.txt"
            rate_file = "rates.txt"
            service_file = "services.txt"
            booking_file = "bookings.txt"
        elif len(args) == 6:
            # Command-line arguments provided
            customer_file, location_file, rate_file, service_file, booking_file = args[1:]
        else:
            #if wrong number of arguments
            print("Usage: python program.py <customer_file> <location_file> <rate_file> <service_file> [booking_file]")
            exit(1)

        try:
            self.records.read_customers(customer_file)
            self.records.read_locations(location_file)
            self.records.read_rates(rate_file)
            self.records.read_services_file(service_file)
            if len(args) == 6:
                self.records.read_bookings(booking_file)  # Load booking data if provided
        except FileNotFoundError as e:
            print(f"Error: {e.filename} is missing. Exiting the program.")
            exit(1)


    def display_customer_booking_history(self):
        customer_name = input("Enter the customer name to display booking history: ")

        # Finding the customer's bookings
        customer_bookings = [booking for booking in self.records.bookings if booking.customer == customer_name]

        if not customer_bookings:
            print(f"No booking history found for {customer_name}.")
            return

        # Printing the table header
        print(f"This is the booking history of {customer_name}:\n")
        print(f"{'Booking':<20}{'Departure':<20}{'Destination':<40}{'Service':<20}{'Total cost':<10}")

        # Iterating through customer's bookings and display them in a table format
        for i, booking in enumerate(customer_bookings, start=1):
            departure = booking.departure
            destinations = ", ".join(booking.destinations)
            service = booking.service
            total_cost = booking.total_cost
            print(f"Booking {i:<5}{departure:<20}{destinations:<40}{service:<20}{total_cost:<10.2f}")


    # this method is used to find the most popular customer based on the total money spent by the customer
    def display_most_popular_customer(self):
        if not self.records.bookings:
            print("No bookings found.")
            return

        customer_spending = {}  # Dictionary to store customer spending
        for booking in self.records.bookings:
            customer_name = booking.customer
            total_cost = booking.total_cost
            if customer_name in customer_spending:
                customer_spending[customer_name] += total_cost
            else:
                customer_spending[customer_name] = total_cost

        max_spending = max(customer_spending.values())                      # Reference ->  (No date a) Python max() function. Available at: https://www.w3schools.com/python/ref_func_max.asp#:~:text=Definition%20and%20Usage,an%20alphabetically%20comparison%20is%20done. (Accessed: 15 October 2023).
        most_popular_customers = [customer for customer, spending in customer_spending.items() if
                                  spending == max_spending]

        print("Most Popular Customer(s):")
        for customer in most_popular_customers:
            print(f"Customer Name: {customer}")
            print(f"Total Spending: ${customer_spending[customer]:.2f}")
            print()

    # this function displays all the bookings of the customer
    def display_all_bookings(self):
        if not self.records.bookings:
            print("No bookings found.")
        else:
            print("\nAll Bookings:")
            for booking in self.records.bookings:
                print("---------------------------------------------------------")
                print("Booking Details:")
                print(f"Customer Name: {booking.customer}")
                print(f"Departure Location: {booking.departure}")
                print("Destinations:")
                for destination, distance in zip(booking.destinations, booking.distances):
                    print(f"  Destination: {destination}")
                    print(f"  Distance: {distance} km")
                print(f"Rate Type: {booking.rate_type}")
                print(f"Service: {booking.service}")
                print(f"Basic Fee: ${booking.basic_fee:.2f}")
                print(f"Distance Fee: ${booking.distance_fee:.2f}")
                print(f"Discount: ${booking.discount:.2f}")
                print(f"Total Cost: ${booking.total_cost:.2f}")
                print("---------------------------------------------------------")



    def display_menu(self):  # display_menu method will display the menu of the programm
        while True:
            print("\nMenu:")
            print("1. Book a trip")
            print("2. Display existing customers")
            print("3. Display existing locations")
            print("4. Display existing rate types")
            print("5. Display existing services")
            print("6. Add New Locations")
            print("7. Adjust the discount rate of all Basic customers")
            print("8. Adjust the discount rate of an Enterprise customer")
            print("9. Add/update rate types and prices")
            print("10.Display All Bookings")
            print("11.Display most valuable customer")
            print("12.Display customer booking history")
            print("0. Exit the program")

            choice = input("Enter your choice: ")
            if choice == "1":
                self.book_trip()
            elif choice == "2":
                self.records.list_customers()
            elif choice == "3":
                self.records.list_locations()
            elif choice == "4":
                self.records.list_rates()
            elif choice == "5":
                self.records.list_services()
            elif choice=="6":
                self.add_new_locations()
            elif choice=="7":
                self.adjust_basic_customer_discount()
            elif choice=="8":
                self.adjust_enterprise_customer_discount()
            elif choice=="9":
                self.add_update_rate_types()
            elif choice=="10":
                self.display_all_bookings()
            elif choice=="11":
                self.display_most_popular_customer()
            elif choice=="12":
                self.display_customer_booking_history()
            elif choice == "0":
                print("Exiting the program.")
                self.save_data()
                break
            else:
                print("Invalid choice. Please select a valid option.")




    # add_update_rate_types() is used to add new rate types or update the existing rate types
    def add_update_rate_types(self):
        action = input("Do you want to add new rate types or update existing ones? (add/update): ")
        if action == "add":
            rate_names = input("Enter rate types (comma-separated): ").split(',')
            prices = input("Enter prices per km (comma-separated): ").split(',')
            for rate_name, price in zip(rate_names, prices):                                      #2. built-in functions¶ (no date) 2. Built-in Functions - Python 3.3.7 documentation. Available at: https://docs.python.org/3.3/library/functions.html#zip (Accessed: 13 October 2023).
                rate_name = rate_name.strip()
                price_per_km = float(price.strip())
                self.records.add_rate_type(rate_name, price_per_km)
            print("Rate types added successfully.")
        elif action == "update":
            rate_name = input("Enter the rate type to update: ")
            new_price = float(input("Enter the new price per km: "))
            self.records.update_rate_type_price(rate_name, new_price)
            print("Rate type price updated successfully.")
        else:
            print("Invalid action. Please enter 'add' or 'update'.")



    # add_new_locations() is used to add new locations to the programm
    def add_new_locations(self):
        new_locationName = input("Enter the location Name you want to add : ")
        if self.records.find_location(new_locationName):
            print("Location Already Exist.")
            return
        len_of_list = len(self.records.locations)
        new_locationID = "L" + str((len_of_list) + 1)

        self.records.locations.append((new_locationID, new_locationName))
        print(f"New Location Added : {new_locationName}")



    # adjust_basic_customer_discount() is used to make the changes to the discount of basic customer
    def adjust_basic_customer_discount(self):
        while True:
            try:
                basic_cust_discount=int(input("Enter the new discount for the Basic customer : "))
                if basic_cust_discount <= 0:
                    raise ValueError("Discount rate must be a positive number.")
                percent=basic_cust_discount/100
                BasicCustomer.set_discount_rate(percent)
                print(f"Discount rate for Basic customers updated to {basic_cust_discount}%")
                return False
            except ValueError as e:
                print(f"Invalid input: {e}. Please enter a valid positive number.")



    # adjust_enterprise_customer_discount() is used to make the changes to the discount of enterprise customer
    def adjust_enterprise_customer_discount(self):
        while True:
            search_value = input("Enter the name or ID of the Enterprise customer: ")
            enterprise_customer_id = None

            # Search for the Enterprise customer in the list of customers
            for customer in self.records.customers:
                if search_value == customer[1] or search_value == str(customer[0]):
                    if customer[2] == 'E':
                        enterprise_customer_id = customer[0]
                        break

            if enterprise_customer_id is None:
                print("Enterprise customer not found or invalid input. Please try again.")
                continue

            try:
                new_discount_rate = float(input("Enter the new first discount rate (e.g., 0.2 for 20%): "))
                if new_discount_rate <= 0:
                    raise ValueError("Discount rate must be a positive number.")
                self.records.update_enterprise_customer_discount(enterprise_customer_id, new_discount_rate)
                break
            except ValueError as e:
                print(f"Invalid input: {e}. Please enter a valid positive number.")



    # book_trip() is used to book a trip
    def book_trip(self):

        while True:
            customer_name = input("Enter customer name: ")  # Taking input for customer_name
            if customer_name.isalpha():
                break
            else:
                print("Enter only alphabets ")
                continue

        customer_info = self.records.find_customer(customer_name)  # searching the customer in existing customers

        if customer_info is None:
            print(
                "New customer detected. Please provide additional information:")  # If the customer is new customer,then we have to add details for it
            customer_type = input("Customer type (B for Basic, E for Enterprise): ")
            if customer_type == "B":
                discount_rate = 0.1
                threshold = None
            elif customer_type == "E":
                discount_rate = float(input("Discount rate for Enterprise customer (%): "))
                threshold = int(input("Threshold for Enterprise customer: "))
            else:
                print("Invalid customer type. Booking canceled.")
                return

            customer_id = len(self.records.customers) + 1  # Generating a new unique ID for customer , if customer is new
            customer_info = (customer_id, customer_name, customer_type, discount_rate, threshold)
            self.records.customers.append(customer_info)  # adding customer to list
            print(f"Customer added successfully with ID {customer_id}.")



        while True:
            departure_location = input("Enter departure location: ")
            departure_location_info = self.records.find_location(departure_location)
            if departure_location_info in self.records.locations:
                break
            else:
                print("Enter Valid Location ")
                continue



        # total_distance = 0
        destination_list = []
        distance_list = []

        # Input loop for destinations and distances
        while True:
            destination_location = input("Enter the destination: ")
            # Check if the destination is valid and different from the departure and previous destinations
            destination_location_info = self.records.find_location(destination_location)
            if destination_location == departure_location or destination_location_info not in self.records.locations:
                print("Invalid destination. Please enter a valid and unique destination.")
                continue
            try:
                distance = float(input(f"Enter the distance from {departure_location} to {destination_location} (km): "))
                if distance <= 0:
                    print("Distance must be greater than 0.")
                    continue
            except ValueError:
                print("Invalid distance. Please enter a valid number.")
                continue

            # Add the destination and distance to the lists
            destination_list.append(destination_location)
            distance_list.append(distance)
            # total_distance += distance

            another_destination = input("Add another destination? (y/n): ")
            if another_destination.lower() != 'y':
                break


        while True:
            rate_name = input("Enter rate type name: ")
            rate_info = self.records.find_rate(rate_name)
            if rate_info is None:
                print("Enter Valid rate type ")
                continue
            else:
                break



         # Initializing empty lists to store service names and package names
        service_names = []
        package_names = []

        # Iterate through the list
        for item in self.records.services:
            if item['ID'].startswith('S'):
               # It's a service
                service_names.append(item['Name'])
            elif item['ID'].startswith('P'):
            # It's a package
                package_names.append(item['Name'])


        while True:
            service=input("Do you want to order extra service/package : ")
            if service=="y" or service=="Y":
                # Printing the service names and package names
                print("Service Names:", service_names)
                print("Package Names:", package_names)
                user_input = input("Enter a service or package: ")

                found_item = None
                for item in self.records.services:
                    if user_input == item['ID'] or user_input == item['Name']:
                        found_item = item
                        break

                if found_item:
                    if found_item['type'] == 'service':
                        print(f"Price of {found_item['Name']} is ${found_item['Price']:.2f}")
                    elif found_item['type'] == 'package':
                        total_price = sum([service['Price'] for service in self.records.services if
                                           service['ID'] in found_item['services']])
                        print(
                            f"Price of {found_item['Name']} package is ${total_price * 0.8:.2f} ")
                        service_fee = (total_price * 0.8)
                        break
                else:
                    print("Service or package not found.")


            elif service=="n" or service=="N":
                service_fee=0
                break

            else:
                print("Enter only Y or N : ")
                continue

        rate_price_per_km = rate_info[2]
        distance_fee, basic_fee, discount, total_cost, service_fee = Booking(customer_name,departure_location,destination_list, rate_price_per_km,distance_list,customer_info[3],service_fee).compute_cost()


        print("\n---------------------------------------------------------")  # printing the receipt for customer
        print("Taxi Receipt")
        print("---------------------------------------------------------")
        print(f"Name: {customer_name}")
        print(f"Departure: {departure_location}")
        for i in range(len(destination_list)):
            print(f"Destination: {destination_list[i]}")
            print(f"Distance: {distance_list[i]} (km)")
        print(f"Rate: {rate_info[2]} (AUD per km)")
        print("---------------------------------------------------------")
        print(f"Basic fee: {basic_fee:.2f} (AUD)")
        print(f"Distance fee: {distance_fee:.2f} (AUD)")
        print(f"Discount: {discount:.2f} (AUD)")
        print(f"Service Fee: {service_fee:.2f} (AUD)")

        print("---------------------------------------------------------")
        print(f"Total cost: {total_cost:.2f} (AUD)")
        print("---------------------------------------------------------")


if __name__ == "__main__":  # This is the starting point for the programmm #It Allows You to Execute Code When the File Runs as a Script
    operations = Operations()
    operations.load_data(sys.argv)
    operations.display_menu()
