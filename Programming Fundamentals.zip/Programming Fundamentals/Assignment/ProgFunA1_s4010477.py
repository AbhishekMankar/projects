
#Name : Abhishek Dnyandeo Mankar
#Student ID : s4010477
#Highest part attempted : part 3
#Problems :

# About Programm:
#----------------------------------------------------------------------------------------------------------------------
# The whole programm is divided into many functions which performs different task.
# When a program is composed of many functions, it is often referred to as a "modular" or "modularized" program.
# The Programm is menu driven and all the options in the menu gives the respected response.


# Challenges faced:
# Storing the customer information in proper format , for proper displaying the booking history.
# retrieving the total money spent by the customer from stored information, to print most valuable customer.



# function to take the name of the customer as input and will pass it to other function callled has_non_aphabet_characters() ,for checking the conditions of name
def name():
    global name1
    name1 = input("Enter the name of the customer : \n")
    has_non_alphabet_characters(name1)
    #customers.append(name1)



# function to take the departure of the customer as input and will pass it to other function callled departure_location_func()
def departure_loc():
    global departure_name
    departure_name = input("Enter the Departure Location : \n")
    departure_location_func(departure_name)
    #exist_locations.append(departure_name)



# function to take the destination of the customer as input and will pass it to other function callled destination_location_func()
def destination_loc():
    global destination_name
    destination_name = input("Enter the Destination Location : \n")
    destination_location_func(destination_name)
    #exist_locations.append(destination_name)


#these are the given values and here these are stored in dictionary
Ratetype_values = {
    'standard': 1.5,
    'peak': 1.8,
    'weekends': 2,
    'holidays': 2.5
}

basic_fee = 4.2   #this is already given

#function to take the rate type as input and will pass it to other function callled rate_type_func()
def rate_type():
    global rate
    #global price
    keys_str = "   ".join(Ratetype_values)
    rate=input("Enter the rate type  : "+str(keys_str)+"\n")
    rate_type_func(rate)



total = 0
#This function takes distance of the journey as input and pass it to distnace_func()
def distance():
    global dist
    global total
    try:
        dist = float(input("Enter the distance (KM) : \n"))
        distance_func(dist)
        total=total+dist             #total variable will store the total distance travelled by the customer
    except:
        print("Enter only numeric value ")
        distance()

#This function will reset the total and discount to 0 after completing the journey of the customer, so for the new customer it will start again from 0.
def reset_total():
    global total
    global discount
    total = 0
    discount = 0



# function to check the name of the customer is written in proper format or not
def has_non_alphabet_characters(name2):
    for char in name2:
        if not char.isalpha():                    #isalpha() is used to check the input consists of alphabets or not
            print("Enter Only alphabets")
            name()

    return False


#These are the existing available locations for the taxi management system
all_location = ["Melbourne", "Chadstone", "Clayton", "Brighton", "Fitzroy"]


# function to again ask customer to add another destination
def ask_another_destination():
    while True:
        ans = input("Do u want to add another destination (y/n) : ")
        if ans == "y":
            destination_loc()
            distance()
        elif ans == "n":
            break



# function to check the departure location of the customer is in available location or not
def departure_location_func(name):
    if name in all_location:
        pass
    else:
        print("Enter Correct Departure Location ")
        departure_loc()




# function to check the destination location of the customer is in available location or not ,and it should not be same as departure location
def destination_location_func(name):
    if name in all_location and name != departure_name:
        pass
    else:
        print("Enter Correct Destination Location and it should not be the departure location")
        destination_loc()



# function to check the rate type entered is correct or not
def rate_type_func(value):
    if value in Ratetype_values:
        pass
    else:
        print("Enter the valid rate type ")
        rate_type()

#function to check the distance value entered by customer is correct or not
def distance_func(value):
    if value<=0:
        print("Enter Proper Distance")
        distance()



customer_list=[]
customer_list2=['Louis','Ella']          #given as per requirements , that Louis,Ella are two existing customers



# Function to book a trip and this function will call all other functions as per need for booking the trip
def book_a_trip():
    global customer_list
    name()
    departure_loc()
    destination_loc()
    distance()
    ask_another_destination()
    rate_type()
    receipt()
    customer_list2.append(name1)
    customer_list.append({                                                  # Updating customer_list with current booking status
        'name': name1,
        'departure': departure_name,
        'destinations': destination_name,
        'total_cost': ((total * Ratetype_values[rate]) + basic_fee)
    })

    reset_total()


# Function to add/update rate types and prices
def add_update_ratetype():
    while True:
        global Ratetype_values
        newratetypes = input("Enter the new Rate Types separated by commas: ")
        newratetypes = [ratetype.strip() for ratetype in newratetypes.split(",")]           #split removes or truncates the given characters from the beginning and the end of the original string

        newprices = input("Enter the prices for the new rate types separated by commas: ")
        try:
            newprices = [float(price.strip()) for price in newprices.split(",")]            #To make sure the new values of new prices entered by the user are read properly
            if all(price > 0 for price in newprices):
                for i in range(len(newratetypes)):
                    Ratetype_values[newratetypes[i]] = newprices[i]                         # assigning the values to the new rate tpye and updating it
                break
            else:
                print("Invalid prices. Prices should be positive numbers.")
        except ValueError:
            print("Invalid input. Please enter valid numbers.")



# function to display all the existing customers
def existing_customers():
    print(customer_list2)



#function to display all the available locations
def existing_locations():
    print(all_location)



#function to print all the ratetypes and its values
def existing_rate():
    suffix = " AUD per km"
    for key, value in Ratetype_values.items():
        modified_value = str(value) + suffix
        print(f"{key}: {modified_value}")



# function to add new locations, and will notify that the location is added or it already exists
def add_new_locations():
        input_string = input("Enter comma-separated values: ")
        input_list = input_string.split(',')                       #Split the input string into a list of elements
        input_list = [element.strip() for element in input_list]   #split() Remove any leading/trailing spaces from each element
        for x in input_list:
            if x not in all_location:
                all_location.append(x)
                print(f"{x} has been added.")

            else:
                print(f"{x} is already an existing location.")


#function to print the most valuable customer
def most_valuable_customer():

    if not customer_list:
        print("No bookings available. Please add bookings first.")
        return

    customer_spending = {}

    # Calculate total spending for each customer
    for booking in customer_list:
        name = booking['name']
        customer_total_cost = booking['total_cost']

        if name in customer_spending:
            customer_spending[name] += customer_total_cost
        else:
            customer_spending[name] = customer_total_cost

    if not customer_spending:
        print("No customer spending data available.")
        return

    max_spending = max(customer_spending.values())

    print("Most Valuable Customer(s):")
    for name, spending in customer_spending.items():
        if spending == max_spending:
            print(f"{name}: ${spending:.2f}")


#function to print the booking history of the customer
def customer_booking_history():

    while True:
        name = input("Enter the name of the customer: ")

        # Find bookings for the specified customer name
        customer_bookings = [booking for booking in customer_list if booking['name'] == name]

        if customer_bookings:
            print(f"This is the booking history of {name}:")
            print("{:<10} {:<10} {:<10} {:<10}".format("", "Departure", "Destination", "Total cost"))                    #hobbes3 et al. (1958) How to format a floating number to fixed width in Python, Stack Overflow. Available at: https://stackoverflow.com/questions/8885663/how-to-format-a-floating-number-to-fixed-width-in-python (Accessed: 27 August 2023).
            for idx, booking in enumerate(customer_bookings, start=1):
                booking_departure = booking['departure']
                booking_destination = booking['destinations']
                booking_total_cost = booking['total_cost']
                print("{:<10} {:<10} {:<10} {:<10}".format(f"Booking {idx}", booking_departure, booking_destination,     # Here i have refer stackoverflow for formatting the output, and the referencing is given above
                                                           booking_total_cost))
            break
        else:
            print(f"No booking history found for customer {name}. Please try again.")

discount = 0
#function to calculate the total cost
def display_total_cost():
    global discount

    final_cost = (Ratetype_values[rate] * total) + 4.2

    if name1 in customer_list2:
        discount=(Ratetype_values[rate] * total)*0.1

    else:
        discount=0
    return final_cost-discount






#function to exit
def exiting():
    print("Closing...")
    exit()





#function to print the receipt
def receipt():
    print("------------------------------------------")
    print("           Taxi Receipt                   ")
    print("------------------------------------------")
    print("Name :             "+name1)
    print("Departure :        "+departure_name)
    print("Destination :      "+destination_name)
    print("Rate :             "+str(Ratetype_values[rate])+" (AUD per km)")
    print("Distance :         "+str(total))
    print("------------------------------------------")
    print("Basic fee :        "+str(basic_fee)+" AUD")
    print("Distance fee :     "+str((Ratetype_values[rate]*total)))
    result = display_total_cost()
    print("Discount fee :     "+str(discount)+" AUD")
    print("------------------------------------------")
    print("Total Cost :      "+str(result))
    if name1 in customer_list2:
        print("You are our existing customer so, 10% discount is given!!")


#these are all the options for the customer
menu_options = {'1': book_a_trip,
                '2': add_update_ratetype,
                '3': existing_customers,
                '4': existing_locations,
                '5': existing_rate,
                '6': add_new_locations,
                '7': most_valuable_customer,
                '8': customer_booking_history,
                '0': exiting
                }



customers = []

#function to print the menu
def show_menu():
    print("WELCOME To TAXI Management System")
    print("#################################")
    print("You can choose from the following ")
    print("1 : Book a trip")
    print("2 : Add/Update rate types and prices")
    print("3 : Display existing customers")
    print("4 : Display existing locations")
    print("5 : Display existing rate types")
    print("6 : Add new Locations")
    print("7 : Display the most valuable customer")
    print("8 : Display a customer booking history")

    print("0 : Exit")
    print("#################################")


#function to ask customer the input and perform that task
while True:
    show_menu()
    choice = input("Choose one option : ")
    selected_option = menu_options.get(choice)
    if selected_option:
        selected_option()
    else:
        print("Invalid choice. Please select a valid option (1/2/3/4).")


