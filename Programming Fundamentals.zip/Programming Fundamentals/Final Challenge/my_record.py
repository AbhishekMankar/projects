#Final Coding challenge
#Name : Abhishek Dnyandeo Mankar
#Student ID: s4010477
#levels attempted:
                #Pass: Completed
                #Credit : Completed
                #DI : Completed
                #HD : in additional requirements, first point of adding score column is not done, except that all requirements are added.



import sys
import datetime

#Defining class dataset with its attributes
class Dataset:
    def __init__(self, dataset_id, name, weight, n_data, source):
        self.dataset_id = dataset_id   #its a unique identifier for a dataset
        self.name = name
        self.weight = weight
        self.n_data = n_data
        self.source = source
        self.results = {}     # self.results{} is a dictionary to store the result for the dataset


    def set_weight(self, weight):    # setting the complexity weight for the dataset
        if weight > 5:
            print(f"Error: Complexity weight for dataset {self.dataset_id} exceeds the limit (5)")
            exit(1)
        self.weight = weight

    def compute_statistics(self):  # computing the statistics based on result for dataset
        completed_results = [result for result in self.results.values() if result is not None and result != '--']
        if completed_results:
            avg_result = sum(completed_results) / len(completed_results)   # calculating average for dataset
            min_result = min(completed_results)                            # calculating min value for dataset
            max_result = max(completed_results)                            # calculating max value for dataset
            num_fail = len(self.results) - len(completed_results)          # calculating total number of failed dataset

        else:
            avg_result = min_result = max_result = num_fail = None
        return avg_result, (min_result, max_result), num_fail        # returns a tuple with calculated statistics



#Defining class algorithm
class Algorithm:
    def __init__(self, name):
        self.name = name       # initializing algorithm with its name
        self.results = {}      # dictionary to store results for algorithm


#Defining class Records
class Records:
    def __init__(self):
        self.datasets = []           # list to store dataset objects
        self.algorithms = []         # list to store algorithm objects
        self.algorithm_info = []     # list to store more information about algorithm
        self.total_algorithms = 0
        self.total_datasets = 0
        self.missing_results = 0
        self.ongoing_results = 0

    # function to read results file
    def read_results(self, result_file_name):
        try:
            with open(result_file_name, 'r') as file:
                lines = file.readlines()
                if not lines:
                    raise ValueError("Error: The result file is empty.")     # if file would be empty then it will show error

                for line in lines:
                    algorithm_name, data = line.strip().split(', ', 1)       # splitting the line in algorithm name and data
                    algorithm = Algorithm(algorithm_name)                    # creating object for algorithm
                    results = data.split(', ')

                    for result in results:                                   # splitting the data in results for each dataset
                        dataset_id, value = result.split(': ')
                        if not value:
                            self.missing_results += 1                        # in case of missing values , it will increment the missing_result variable
                            algorithm.results[dataset_id] = None
                        elif value == '404':                                 # it will print "--" in place where the process is ongoing
                            self.ongoing_results += 1
                            algorithm.results[dataset_id] = '--'
                        else:
                            try:
                                value = float(value)
                            except ValueError:
                                raise ValueError(f"Error: Invalid result value for dataset {dataset_id}: {value}")
                            algorithm.results[dataset_id] = value
                    self.algorithms.append(algorithm)                       # appending the object to the list of algorithms

                if not self.algorithms:
                    raise ValueError("Error: No valid results found in the result file.")


                # calculating statistics for the results
                self.total_algorithms = len(self.algorithms)
                self.total_datasets = len(self.algorithms[0].results)
                self.datasets = [Dataset(dataset_id, "", 1, 0, "") for dataset_id in self.algorithms[0].results.keys()]


        # it will show error when the file will not found and exit the programm
        except FileNotFoundError:
            raise FileNotFoundError(f"Error: File not found: {result_file_name}")


    # function to read datasets file
    def read_datasets(self, dataset_file_name):
        try:
            with open(dataset_file_name, 'r') as file:
                lines = file.readlines()
                for line in lines:
                    dataset_id, name, weight, n_data, source = line.strip().split(', ')
                    dataset = next((ds for ds in self.datasets if ds.dataset_id == dataset_id), None)
                    if dataset:                 # updating the dataset attributes
                        dataset.name = name
                        dataset.set_weight(int(weight))
                        dataset.n_data = int(n_data)
                        dataset.source = source
                    else:
                        print(f"Dataset ID {dataset_id} not found in result file.")
                        exit(1)

        # it will show error when the file will not found and exit the programm
        except FileNotFoundError:
            print("File not found:", dataset_file_name)
            exit(1)


    # function to display Results in proper tabular format
    def display_results(self):
        print("\nRESULTS")

        # Printing header for the table
        header = ["| Algorithm"] + [dataset.dataset_id for dataset in self.datasets]
        print("------------------------------------------------------------------------")
        print("{:<15} ".format(header[0]), end="")                  # giving spacing between header for making proper formatting
        for column in header[1:]:
            print(f"{column:>10} ", end="")

        print("|")
        print("------------------------------------------------------------------------")


        # printing rows for the table
        for algorithm in self.algorithms:
            print(f"| {algorithm.name:<15} ", end="")

            for dataset in self.datasets:
                result = algorithm.results.get(dataset.dataset_id)
                if result is None:
                    print("XX".rjust(10), end="")
                elif result == '--':
                    print("--".rjust(10), end="")
                else:
                    print(f"{result:.1f}".rjust(10), end="")
            print("   |")
        print("------------------------------------------------------------------------")
        print("\nRESULTS SUMMARY")                         # showing Summary for Results table
        print(f"There are {self.total_algorithms} algorithms and {self.total_datasets} datasets")
        print(
            f"The number of nonexistent results is {self.missing_results} and on-going results is {self.ongoing_results}\n")


    # function to display Datasets in proper tabular format
    def generate_dataset_table(self):

        print("\nDATASET INFORMATION")
        # Splitting the dataset into simple(S) and advanced(A) on datasetID
        simple_datasets = [dataset for dataset in self.datasets if dataset.dataset_id.endswith("S")]
        advanced_datasets = [dataset for dataset in self.datasets if dataset.dataset_id.endswith("A")]

        # Sorting the datasets based on the Average column in descending order
        simple_datasets.sort(key=lambda dataset: dataset.compute_statistics()[0] if dataset.compute_statistics()[0] is not None else float('-inf'), reverse=True)
        advanced_datasets.sort(key=lambda dataset: dataset.compute_statistics()[0] if dataset.compute_statistics()[0] is not None else float('-inf'), reverse=True)

        # Creating and printing the header for the simple dataset table
        print("\nSIMPLE DATASET TABLE")
        print("-" * 138)
        header = ["DatasetID", "Name", "Type", "Weight", "Ndata", "Source", "Average", "Range", "       Nfail   |"]
        print("|", end="")
        for column in header:
            print(f" {column:>13} ", end="")
        print()
        print("-" * 138)

        # Initializing self.results for each dataset
        for dataset in self.datasets:
            dataset.results = {}

        # Populating self.results with results from algorithms and count missing results values
        missing_results_count = {}
        for algorithm in self.algorithms:
            for dataset in self.datasets:
                result = algorithm.results.get(dataset.dataset_id)
                if result is not None:
                    dataset.results[algorithm.name] = result
                else:
                    missing_results_count[dataset.dataset_id] = missing_results_count.get(dataset.dataset_id, 0) + 1     # Counting the missing results for this dataset

        for dataset in simple_datasets:
            avg, (min_res, max_res), _ = dataset.compute_statistics()
            dataset_type = "S" if dataset.dataset_id.endswith("S") else "A"

            avg_str = f"{avg:.1f}" if avg is not None else 'N/A'
            range_str = f"{min_res:.1f}" if min_res is not None else 'N/A'
            if min_res is not None and max_res is not None:
                range_str += f" - {max_res:.1f}"

            # Using missing_results_count to get the missing results count for this dataset
            num_fail_count = missing_results_count.get(dataset.dataset_id, 0)
            num_fail_str = str(num_fail_count) if num_fail_count != 0 else '0'

            print(
                f"| {dataset.dataset_id:>13}   {dataset.name:>13}  {dataset_type:>13}  {dataset.weight:>13}  {dataset.n_data:>13}  {dataset.source:>13}  {avg_str:>13}  {range_str:>13}  {num_fail_str:>13} |")
        print("-" * 138)

        # Creating and printing the header for the advanced dataset table
        print("\nADVANCED DATASET TABLE")
        print("-" * 138)
        print("|", end="")
        for column in header:
            print(f" {column:>13} ", end="")
        print()
        print("-" * 138)

        for dataset in advanced_datasets:
            avg, (min_res, max_res), _ = dataset.compute_statistics()
            dataset_type = "S" if dataset.dataset_id.endswith("S") else "A"

            avg_str = f"{avg:.1f}" if avg is not None else 'N/A'
            range_str = f"{min_res:.1f}" if min_res is not None else 'N/A'
            if min_res is not None and max_res is not None:
                range_str += f" - {max_res:.1f}"

            # Using the missing_results_count to get the missing results count for this dataset
            num_fail_count = missing_results_count.get(dataset.dataset_id, 0)
            num_fail_str = str(num_fail_count) if num_fail_count != 0 else '0'

            print(
                f"| {dataset.dataset_id:>13}   {dataset.name:>13}  {dataset_type:>13}  {dataset.weight:>13}  {dataset.n_data:>13}  {dataset.source:>13}  {avg_str:>13}  {range_str:>13}  {num_fail_str:>13} |")
        print("-" * 138)

        most_difficult_datasets = self.find_most_difficult_datasets(simple_datasets + advanced_datasets)
        most_fail_datasets = self.find_most_fail_datasets(missing_results_count, simple_datasets + advanced_datasets)

        #Printing the Summary for dataset
        print("\nDATASET SUMMARY")
        # Finding and Displaying the most difficult dataset from both simple and advanced dataset table
        if most_difficult_datasets:
            most_difficult_dataset = most_difficult_datasets[0]
            avg_difficult, _, _ = most_difficult_dataset.compute_statistics()   # taking only average from statistics for summary
            print(
                f"The most difficult dataset is {most_difficult_dataset.name} with an average result of {avg_difficult:.1f}")

        # Finding and Displaying the dataset with the most failures from both simple and advanced datasets
        if most_fail_datasets:
            most_fail_dataset = most_fail_datasets[0]
            num_fail_count = missing_results_count.get(most_fail_dataset.dataset_id, 0)
            print(
                f"The dataset with the most failures is {most_fail_dataset.name}, with the number of failures being {num_fail_count}\n")

        print()


    # function to find most difficult dataset
    def find_most_difficult_datasets(self, datasets):
        lowest_avg = None                                 # variable to keep the value of the lowest average result
        most_difficult_datasets = []                      # list to store the most difficult dataset

        for dataset in datasets:
            avg, _, _ = dataset.compute_statistics()      # calculating the average result for current dataset
            if avg is not None and (lowest_avg is None or avg < lowest_avg):    # checking if the dataset has a valid average result and if it's lower than the lowest found till now
                lowest_avg = avg
                most_difficult_datasets = [dataset]       # replace the list with the new most difficult dataset
            elif avg == lowest_avg:
                most_difficult_datasets.append(dataset)   # adding to the list if it's same

        return most_difficult_datasets


    # function to find most fail dataset
    def find_most_fail_datasets(self, missing_results_count, datasets):
        # Find the dataset(s) with the most failures
        highest_failures = None                           # variable to keep the value of most failures
        most_fail_datasets = []                           # list to store the most difficult dataset

        for dataset in datasets:
            num_fail = missing_results_count.get(dataset.dataset_id, 0)
            if highest_failures is None or num_fail > highest_failures:    # checking if the current dataset has more failures than the previously identified
                highest_failures = num_fail
                most_fail_datasets = [dataset]
            elif num_fail == highest_failures:
                most_fail_datasets.append(dataset)

        return most_fail_datasets


    # function to read algorithm file
    def read_algorithm_info(self, algorithm_file_name):
        try:
            with open(algorithm_file_name, 'r') as file:
                lines = file.readlines()
                for line in lines:
                    algorithm_data = line.strip().split(', ')                # splitting the line into different components from algorithm file
                    name, algorithm_type, year, *authors = algorithm_data
                    authors = "-".join(authors)                              # there may be more than one author
                    algorithm_info = AlgorithmInfo(name, algorithm_type, int(year), authors)     # creating instance of algorithm_info
                    self.algorithm_info.append(algorithm_info)

        # it will show error when the file will not found and exit the programm
        except FileNotFoundError:
            print("File not found:", algorithm_file_name)
            exit(1)


    # function to update the algorithm information
    def update_algorithm_info(self):
        algorithm_results = {algorithm.name: algorithm.results for algorithm in self.algorithms}

        for algorithm_info in self.algorithm_info:
            algorithm_info.results = algorithm_results.get(algorithm_info.name, {})

        for algorithm_info in self.algorithm_info:
            algorithm_info.compute_statistics()


    # function to display algorithm table
    def display_algorithm_table(self):

        print("\nALGORITHM INFORMATION")

        # Splitting the algorithms into ML and DL table based on the algorithm_type
        ml_algorithms = [algorithm_info for algorithm_info in self.algorithm_info if algorithm_info.algorithm_type == 'ML']
        dl_algorithms = [algorithm_info for algorithm_info in self.algorithm_info if algorithm_info.algorithm_type == 'DL']

        # Defining the header for algorithm tables
        header = ["       Name", "            Type", "          Year", "       Authors", "          Average", "         Nfail", "  FailDataset", "      Nongoing |"]

        # Defining coloumn widths for algorithm table
        column_widths = [15, 15, 15, 15, 15, 15, 15, 15]

        # Creating and printing the header for the ML algorithm table
        print("\n")
        print("ML ALGORITHMS")
        print("-" * 132)
        print("|", end="")
        for i, column in enumerate(header):                   #Enumerate() in Python (2023) GeeksforGeeks. Available at: https://www.geeksforgeeks.org/enumerate-in-python/ (Accessed: 28 October 2023).
            print(column.ljust(column_widths[i]), end=" ")
        print()
        print("-" * 132)

        # Printing ML algorithm rows
        for algorithm_info in ml_algorithms:
            meets_requirements = algorithm_info.meets_requirements()
            algorithm_name = algorithm_info.name
            if not meets_requirements:
                algorithm_name += '!'
            authors = algorithm_info.authors
            average_str = f"{algorithm_info.average_results:.1f}" if algorithm_info.average_results is not None else 'N/A'
            fail_data = ", ".join(algorithm_info.failed_datasets) if algorithm_info.failed_datasets else ''
            num_fail = str(algorithm_info.num_failed_datasets)
            num_ongoing = str(algorithm_info.num_ongoing_results)

            data = [algorithm_name, algorithm_info.algorithm_type, str(algorithm_info.year),
                    authors, average_str, num_fail, fail_data, num_ongoing]

            print("|", end=" ")
            for i, item in enumerate(data):
                print(item.rjust(column_widths[i]), end=" ")             # String rjust() and ljust() in Python() (2018) GeeksforGeeks. Available at: https://www.geeksforgeeks.org/string-rjust-ljust-python/ (Accessed: 28 October 2023).
            print(" |")
        print("-" * 132)



        # Creating and printing the header for the DL algorithm table
        print("\n")

        print("DL ALGORITHMS")
        print("-" * 132)
        print("|", end="")
        for i, column in enumerate(header):
            print(column.ljust(column_widths[i]), end=" ")
        print()
        print("-" * 132)

        # Printing DL algorithm rows
        for algorithm_info in dl_algorithms:
            meets_requirements = algorithm_info.meets_requirements()
            algorithm_name = algorithm_info.name
            if not meets_requirements:
                algorithm_name += '!'
            authors = algorithm_info.authors
            average_str = f"{algorithm_info.average_results:.1f}" if algorithm_info.average_results is not None else 'N/A'
            fail_data = ", ".join(algorithm_info.failed_datasets) if algorithm_info.failed_datasets else ''
            num_fail = str(algorithm_info.num_failed_datasets)
            num_ongoing = str(algorithm_info.num_ongoing_results)

            data = [algorithm_name, algorithm_info.algorithm_type, str(algorithm_info.year),
                    authors, average_str, num_fail, fail_data, num_ongoing]

            print("|", end=" ")
            for i, item in enumerate(data):
                print(item.rjust(column_widths[i]), end=" ")
            print(" |")
        print("-" * 132)


        # printing the summary for algorithm table
        print("\nALGORITHM SUMMARY")
        best_algorithms = self.find_best_algorithm()
        least_failures_algorithms = self.find_least_failures_algorithm()

        if best_algorithms:
            best_avg_result = best_algorithms[0].average_results

            # Displaying the best algorithm with the highest average result
            best_algorithms = [alg for alg in best_algorithms if alg.average_results == best_avg_result]
            best_algorithm_names = [alg.name for alg in best_algorithms]

            if len(best_algorithm_names) == 1:
                print(
                    f"The best algorithm is {best_algorithm_names[0]} with an average result of {best_avg_result:.1f}")

            elif len(best_algorithm_names) > 1:
                print(
                    f"The best algorithms with the highest average result ({best_avg_result:.1f}): {', '.join(best_algorithm_names)}")

        if least_failures_algorithms:
            least_failures = least_failures_algorithms[0].num_failed_datasets

            # Displaying the algorithm with the least number of failures
            least_failures_algorithms = [alg for alg in least_failures_algorithms if
                                         alg.num_failed_datasets == least_failures]
            least_failures_algorithm_names = [alg.name for alg in least_failures_algorithms]

            if len(least_failures_algorithm_names) == 1:
                print(
                    f"The algorithm with the least number of failures is {least_failures_algorithm_names[0]} with the number of failures being {least_failures}. ")

            elif len(least_failures_algorithm_names) > 1:
                print(
                    f"The algorithms with the least number of failures is {least_failures_algorithm_names[(len(least_failures_algorithm_names)-1)]} with the number of failures being {least_failures}. \n")


    # function to find the best algorithm based on highest average results
    def find_best_algorithm(self):
        # Find the best algorithm(s) with the highest average result
        best_algorithms = [alg for alg in self.algorithm_info if alg.average_results is not None]
        if best_algorithms:
            best_avg = max([alg.average_results for alg in best_algorithms])
            best_algorithms = [alg for alg in best_algorithms if alg.average_results == best_avg]
        return best_algorithms

    # function to find least failures algorithms among all the algorithm
    def find_least_failures_algorithm(self):
        # Find the algorithm(s) with the least number of failures
        least_failures = min([alg.num_failed_datasets for alg in self.algorithm_info])
        least_failures_algorithms = [alg for alg in self.algorithm_info if alg.num_failed_datasets == least_failures]
        return least_failures_algorithms


# Defining class AlgorithmInfo
class AlgorithmInfo:
    def __init__(self, name, algorithm_type, year, authors):
        self.name = name
        self.algorithm_type = algorithm_type
        self.year = year
        self.authors = authors
        self.results = []   # self.results{} is a dictionary to store the algorithm for the dataset


    # function to compute statistics based on the stored results for algorithm
    def compute_statistics(self):
        completed_results = [result for result in self.results.values() if result is not None and result != '--']        # calculating average

        num_ongoing_results = sum(1 for result in self.results.values() if result == '--')                               # calulating total number of failed datasets
        self.num_ongoing_results = num_ongoing_results                                                                   # calulating total number of ongoing results

        if completed_results:
            self.average_results = sum(completed_results) / len(completed_results)
            self.failed_datasets = [dataset for dataset, result in self.results.items() if result is None]
            self.num_failed_datasets = len(self.failed_datasets)

    def meets_requirements(self):
        if self.algorithm_type == 'ML':
            return self.num_failed_datasets <= 1 and self.num_ongoing_results <= 1
        elif self.algorithm_type == 'DL':
            return self.num_failed_datasets <= 2 and self.num_ongoing_results <= 2
        return False



if __name__ == "__main__":   # starting point of the code
    if len(sys.argv) == 1:   # when the input is "python my_record.py" , then it will ask to add more arguments
        print("Usage: python my_record.py <result_file_name> <dataset_file_name> <algorithm_file_name>")
        

    elif len(sys.argv) == 2: # when the input is "python my_record.py results.txt" , then it will print and store RESULTS table
        result_file_name = sys.argv[1]
        records = Records()
        try:
            records.read_results(result_file_name)
            print("Results read successfully.")
        except Exception as e:
            print("Error reading results:", e)

        records.display_results()

        with open('reports.txt', 'a') as report_file:  # Open the file in append mode
            current_datetime = datetime.datetime.now()
            report_file.write(current_datetime.strftime("%d/%m/%Y %H:%M:%S") + "\n")  # Write date and time
            sys.stdout = report_file  # Redirecting the standard output to the file

            records.display_results()
            sys.stdout = sys.__stdout__  # Reset standard output back to its original state

        print("\nReports have been saved in 'reports.txt'.")

    elif len(sys.argv) == 3:          # when the input is "python my_record.py results.txt datasets.txt" , then it will print and store RESULTS , DATASET INFORMATION table
        result_file_name = sys.argv[1]
        dataset_file_name = sys.argv[2]
        records = Records()
        try:
            records.read_results(result_file_name)
            print("Results read successfully.")
        except Exception as e:
            print("Error reading results:", e)

        try:
            records.read_datasets(dataset_file_name)
            print("Datasets read successfully.")
        except Exception as e:
            print("Error reading datasets:", e)

        records.display_results()
        records.generate_dataset_table()

        with open('reports.txt', 'a') as report_file:  # Open the file in append mode
            current_datetime = datetime.datetime.now()
            report_file.write(current_datetime.strftime("%d/%m/%Y %H:%M:%S") + "\n")  # Write date and time
            sys.stdout = report_file  # Redirect standard output to the file

            records.display_results()
            records.generate_dataset_table()
            sys.stdout = sys.__stdout__  # Reset standard output

        print("\nReports have been saved in 'reports.txt'.")


    elif len(sys.argv) == 4:               # when the input is "python my_record.py results.txt datasets.txt algorithms.txt" , then it will print and store RESULTS , DATASET INFORMATION and ALGORITHM INFORMATION table
        result_file_name = sys.argv[1]
        dataset_file_name = sys.argv[2]
        algorithm_file_name = sys.argv[3]
        records = Records()
        try:
            records.read_results(result_file_name)
            print("Results read successfully.")
        except Exception as e:
            print("Error reading results:", e)

        try:
            records.read_datasets(dataset_file_name)
            print("Datasets read successfully.")
        except Exception as e:
            print("Error reading datasets:", e)

        try:
            records.read_algorithm_info(algorithm_file_name)
            print("Algorithm info read successfully.")
        except Exception as e:
            print("Error reading algorithm info:", e)

        records.update_algorithm_info()

        records.display_results()
        records.generate_dataset_table()
        records.display_algorithm_table()

        with open('reports.txt', 'a') as report_file:  # Open the file in append mode
            current_datetime = datetime.datetime.now()
            report_file.write(current_datetime.strftime("%d/%m/%Y %H:%M:%S") + "\n")  # Write date and time
            sys.stdout = report_file  # Redirect standard output to the file

            records.display_results()
            records.generate_dataset_table()
            records.display_algorithm_table()
            sys.stdout = sys.__stdout__  # Reset standard output

        print("\nReports have been saved in 'reports.txt'.")








